<?php
require_once '../config/db.php';
require_once '../config/fare_helper.php';
requireRole('rider');

// Get rider ID
$stmt = $pdo->prepare("SELECT id, status FROM riders WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$rider = $stmt->fetch();

if (!$rider || !isset($rider['id'])) {
    header('Location: dashboard.php?error=no_profile');
    exit();
}

$rider_id = $rider['id'];

if ($rider['status'] != 'active') {
    header('Location: dashboard.php');
    exit();
}

$fare_calculator = new FareCalculator($pdo);
$message = '';
$error = '';
$fare_breakdown = null;

// Check for ongoing trip
$ongoing = $pdo->prepare("SELECT * FROM trips WHERE rider_id = ? AND status = 'ongoing'");
$ongoing->execute([$rider_id]);
$ongoing_trip = $ongoing->fetch();

// Start a new trip
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['start_trip'])) {
    $start_location = trim($_POST['start_location']);
    $estimated_distance = floatval($_POST['estimated_distance'] ?? 0);
    $estimated_duration = intval($_POST['estimated_duration'] ?? 0);
    
    if (empty($start_location)) {
        $error = "Please enter start location";
    } else {
        $stmt = $pdo->prepare("INSERT INTO trips (rider_id, start_location, start_time, status, distance_km, duration_minutes) VALUES (?, ?, NOW(), 'ongoing', ?, ?)");
        if ($stmt->execute([$rider_id, $start_location, $estimated_distance, $estimated_duration])) {
            $message = "Trip started successfully!";
            logActivity($_SESSION['user_id'], "Started new trip from $start_location");
            header('Location: manage_trips.php');
            exit();
        } else {
            $error = "Failed to start trip";
        }
    }
}

// End current trip
if (isset($_GET['end'])) {
    $end_location = trim($_GET['end_location'] ?? 'Destination reached');
    $actual_distance = floatval($_GET['distance'] ?? 0);
    $actual_duration = intval($_GET['duration'] ?? 0);
    $trip_id = intval($_GET['end']);
    
    if ($actual_distance <= 0) {
        $error = "Please enter a valid distance";
    } else {
        // Get trip details
        $stmt = $pdo->prepare("SELECT * FROM trips WHERE id = ? AND rider_id = ? AND status = 'ongoing'");
        $stmt->execute([$trip_id, $rider_id]);
        $trip = $stmt->fetch();
        
        if ($trip) {
            // Calculate fare
            $fare_breakdown = $fare_calculator->getFareBreakdown($actual_distance, $actual_duration);
            $total_fare = $fare_breakdown['total_fare'];
            
            // Update trip with fare
            $stmt = $pdo->prepare("
                UPDATE trips 
                SET end_location = ?, end_time = NOW(), status = 'completed', 
                    distance_km = ?, duration_minutes = ?, fare = ?, fare_breakdown = ?
                WHERE id = ? AND rider_id = ? AND status = 'ongoing'
            ");
            $stmt->execute([
                $end_location, $actual_distance, $actual_duration, $total_fare, 
                json_encode($fare_breakdown), $trip_id, $rider_id
            ]);
            
            $_SESSION['last_trip_fare'] = $total_fare;
            $_SESSION['last_trip_breakdown'] = $fare_breakdown;
            
            $message = "Trip completed successfully! Fare: KES " . number_format($total_fare);
            logActivity($_SESSION['user_id'], "Ended trip. Distance: {$actual_distance}km, Fare: KES $total_fare");
            header('Location: manage_trips.php?completed=1');
            exit();
        } else {
            $error = "Trip not found";
        }
    }
}

// Calculate estimate
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['calculate_estimate'])) {
    $estimated_distance = floatval($_POST['estimated_distance'] ?? 0);
    $estimated_duration = intval($_POST['estimated_duration'] ?? 0);
    
    if ($estimated_distance > 0 || $estimated_duration > 0) {
        $fare_breakdown = $fare_calculator->getFareBreakdown($estimated_distance, $estimated_duration);
    } else {
        $error = "Please enter distance or duration for estimate";
    }
}

include '../includes/header.php';
include '../includes/sidebar.php';
?>

<style>
    .fare-card {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        border-radius: 15px;
        padding: 20px;
        margin-top: 20px;
    }
    .fare-amount {
        font-size: 36px;
        font-weight: bold;
    }
    .breakdown-item {
        display: flex;
        justify-content: space-between;
        padding: 8px 0;
        border-bottom: 1px solid rgba(255,255,255,0.2);
    }
    .multiplier-badge {
        background: #ff9800;
        color: white;
        padding: 5px 10px;
        border-radius: 20px;
        font-size: 12px;
    }
    .route-info {
        background: #e8f5e9;
        border-left: 4px solid #4caf50;
        padding: 15px;
        border-radius: 10px;
        margin-top: 15px;
    }
    .distance-hint {
        font-size: 12px;
        color: #6c757d;
        margin-top: 5px;
    }
</style>

<div class="row">
    <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                <h5><i class="fas fa-play-circle"></i> <?php echo $ongoing_trip ? 'Current Trip' : 'Start New Trip'; ?></h5>
            </div>
            <div class="card-body">
                <?php if (isset($_GET['completed'])): ?>
                    <div class="alert alert-success">
                        <i class="fas fa-check-circle"></i> Trip completed successfully!
                        <?php if (isset($_SESSION['last_trip_fare'])): ?>
                            <br><strong>Total Fare: KES <?php echo number_format($_SESSION['last_trip_fare']); ?></strong>
                            <?php unset($_SESSION['last_trip_fare']); ?>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
                
                <?php if ($message): ?>
                    <div class="alert alert-success"><?php echo $message; ?></div>
                <?php endif; ?>
                <?php if ($error): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>
                
                <?php if ($ongoing_trip): ?>
                    <!-- ONGOING TRIP VIEW -->
                    <div class="alert alert-info">
                        <strong><i class="fas fa-motorcycle"></i> Trip in Progress!</strong><br>
                        Started: <?php echo date('Y-m-d H:i:s', strtotime($ongoing_trip['start_time'])); ?><br>
                        From: <?php echo htmlspecialchars($ongoing_trip['start_location']); ?>
                        <?php if ($ongoing_trip['distance_km'] > 0): ?>
                            <br>Estimated Distance: <?php echo $ongoing_trip['distance_km']; ?> km
                            <br>Estimated Duration: <?php echo $ongoing_trip['duration_minutes']; ?> min
                        <?php endif; ?>
                    </div>
                    
                    <form method="GET" onsubmit="return validateEndTrip()">
                        <input type="hidden" name="end" value="<?php echo $ongoing_trip['id']; ?>">
                        
                        <div class="mb-3">
                            <label><i class="fas fa-flag-checkered"></i> End Location *</label>
                            <input type="text" name="end_location" id="end_location" class="form-control" placeholder="Enter destination" required>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label><i class="fas fa-road"></i> Actual Distance (km) *</label>
                                <input type="number" name="distance" id="distance" class="form-control" step="0.1" placeholder="e.g., 5.5" required>
                                <div class="distance-hint">
                                    <i class="fas fa-info-circle"></i> Enter the actual distance traveled
                                </div>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label><i class="fas fa-clock"></i> Actual Duration (minutes) *</label>
                                <input type="number" name="duration" id="duration" class="form-control" placeholder="e.g., 15" required>
                                <div class="distance-hint">
                                    <i class="fas fa-info-circle"></i> Enter the actual trip duration
                                </div>
                            </div>
                        </div>
                        
                        <div id="farePreview" class="route-info" style="display: none;">
                            <strong><i class="fas fa-calculator"></i> Fare Preview:</strong>
                            <div id="previewDetails"></div>
                        </div>
                        
                        <button type="submit" class="btn btn-danger w-100 mt-3" id="endTripBtn">
                            <i class="fas fa-flag-checkered"></i> End Trip & Calculate Fare
                        </button>
                    </form>
                    
                <?php else: ?>
                    <!-- START NEW TRIP FORM -->
                    <form method="POST" id="startTripForm">
                        <div class="mb-3">
                            <label><i class="fas fa-map-marker-alt"></i> Start Location *</label>
                            <input type="text" name="start_location" id="start_location" class="form-control" placeholder="e.g., CBD, Westlands, Kilimani" required>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label><i class="fas fa-road"></i> Estimated Distance (km)</label>
                                <input type="number" name="estimated_distance" id="estimated_distance" class="form-control" step="0.1" placeholder="e.g., 5.5">
                                <div class="distance-hint">
                                    <i class="fas fa-info-circle"></i> Optional - for fare estimate
                                </div>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label><i class="fas fa-clock"></i> Estimated Duration (minutes)</label>
                                <input type="number" name="estimated_duration" id="estimated_duration" class="form-control" placeholder="e.g., 15">
                                <div class="distance-hint">
                                    <i class="fas fa-info-circle"></i> Optional - for fare estimate
                                </div>
                            </div>
                        </div>
                        
                        <div class="mt-2">
                            <button type="button" onclick="calculateEstimate()" class="btn btn-info">
                                <i class="fas fa-calculator"></i> Calculate Fare Estimate
                            </button>
                            <button type="submit" name="start_trip" class="btn btn-success">
                                <i class="fas fa-play"></i> Start Trip
                            </button>
                        </div>
                    </form>
                    
                    <!-- Fare Estimate Display -->
                    <?php if ($fare_breakdown): ?>
                    <div class="fare-card">
                        <h6><i class="fas fa-receipt"></i> Fare Estimate</h6>
                        <div class="fare-amount text-center">KES <?php echo number_format($fare_breakdown['total_fare']); ?></div>
                        
                        <div class="mt-3">
                            <div class="breakdown-item">
                                <span>Base Fare</span>
                                <span>KES <?php echo number_format($fare_breakdown['base_fare']); ?></span>
                            </div>
                            <div class="breakdown-item">
                                <span>Distance (<?php echo $fare_breakdown['distance_km']; ?> km @ KES <?php echo $fare_calculator->getSettings()['per_km_rate']; ?>/km)</span>
                                <span>KES <?php echo number_format($fare_breakdown['distance_fare']); ?></span>
                            </div>
                            <?php if ($fare_breakdown['duration_minutes'] > 0): ?>
                            <div class="breakdown-item">
                                <span>Time (<?php echo $fare_breakdown['duration_minutes']; ?> min @ KES <?php echo $fare_calculator->getSettings()['per_minute_rate']; ?>/min)</span>
                                <span>KES <?php echo number_format($fare_breakdown['time_fare']); ?></span>
                            </div>
                            <?php endif; ?>
                            <div class="breakdown-item">
                                <span>Subtotal</span>
                                <span>KES <?php echo number_format($fare_breakdown['subtotal']); ?></span>
                            </div>
                            <?php if ($fare_breakdown['multiplier'] > 1): ?>
                            <div class="breakdown-item">
                                <span><?php echo $fare_breakdown['multiplier_name']; ?> (x<?php echo $fare_breakdown['multiplier']; ?>)</span>
                                <span><span class="multiplier-badge">+<?php echo round(($fare_breakdown['multiplier'] - 1) * 100); ?>%</span></span>
                            </div>
                            <?php endif; ?>
                            <div class="breakdown-item fw-bold">
                                <span>Total Fare</span>
                                <span>KES <?php echo number_format($fare_breakdown['total_fare']); ?></span>
                            </div>
                        </div>
                        <small class="d-block text-center mt-2">
                            <i class="fas fa-info-circle"></i> This is an estimate. Final fare calculated at trip end.
                        </small>
                    </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <div class="col-md-6">
        <!-- Fare Information Card -->
        <div class="card">
            <div class="card-header">
                <h5><i class="fas fa-info-circle"></i> Fare Information</h5>
            </div>
            <div class="card-body">
                <h6>Current Rates:</h6>
                <table class="table table-sm">
                    <?php $settings = $fare_calculator->getSettings(); ?>
                    <tr>
                        <th>Base Fare:</th>
                        <td>KES <?php echo number_format($settings['base_fare']); ?></td>
                    </tr>
                    <tr>
                        <th>Per Kilometer:</th>
                        <td>KES <?php echo number_format($settings['per_km_rate']); ?>/km</td>
                    </tr>
                    <tr>
                        <th>Per Minute:</th>
                        <td>KES <?php echo number_format($settings['per_minute_rate']); ?>/min</td>
                    </tr>
                    <tr>
                        <th>Minimum Fare:</th>
                        <td>KES <?php echo number_format($settings['minimum_fare']); ?></td>
                    </tr>
                </table>
                
                <h6 class="mt-3">Multipliers:</h6>
                <table class="table table-sm">
                    <tr>
                        <th>Peak Hours (7-9am, 5-7pm):</th>
                        <td>x<?php echo $settings['peak_hour_multiplier']; ?></td>
                    </tr>
                    <tr>
                        <th>Night Time (10pm-5am):</th>
                        <td>x<?php echo $settings['night_multiplier']; ?></td>
                    </tr>
                </table>
                
                <div class="alert alert-info mt-3">
                    <i class="fas fa-lightbulb"></i> <strong>How fare is calculated:</strong><br>
                    Fare = (Base Fare + Distance Fare + Time Fare) × Time Multiplier<br>
                    Minimum fare applies if total is below minimum.
                </div>
                
                <div class="alert alert-secondary mt-2">
                    <i class="fas fa-tape"></i> <strong>Distance Guide:</strong><br>
                    • Short trip (within estate): 1-3 km<br>
                    • Medium trip (nearby areas): 3-8 km<br>
                    • Long trip (cross town): 8-15 km
                </div>
            </div>
        </div>
        
        <!-- Recent Trips -->
        <div class="card mt-3">
            <div class="card-header">
                <h5><i class="fas fa-history"></i> Recent Trips</h5>
            </div>
            <div class="card-body">
                <?php
                $recent_completed = $pdo->prepare("
                    SELECT * FROM trips 
                    WHERE rider_id = ? AND status = 'completed' 
                    ORDER BY created_at DESC 
                    LIMIT 5
                ");
                $recent_completed->execute([$rider_id]);
                $recent_trips = $recent_completed->fetchAll();
                ?>
                
                <?php if (count($recent_trips) > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>From → To</th>
                                    <th>Distance</th>
                                    <th>Fare</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recent_trips as $trip): ?>
                                <tr>
                                    <td><?php echo date('d M H:i', strtotime($trip['created_at'])); ?></td>
                                    <td><?php echo substr(htmlspecialchars($trip['start_location']), 0, 12); ?> → <?php echo substr(htmlspecialchars($trip['end_location']), 0, 12); ?></td>
                                    <td><?php echo $trip['distance_km']; ?> km</td>
                                    <td><strong>KES <?php echo number_format($trip['fare']); ?></strong></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <p class="text-muted text-center">No completed trips yet.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script>
// Calculate fare estimate
function calculateEstimate() {
    var distance = document.getElementById('estimated_distance').value;
    var duration = document.getElementById('estimated_duration').value;
    
    if (!distance && !duration) {
        alert('Please enter either distance or duration to calculate estimate');
        return;
    }
    
    // Submit form to calculate estimate
    var form = document.createElement('form');
    form.method = 'POST';
    form.action = '';
    
    var distanceInput = document.createElement('input');
    distanceInput.type = 'hidden';
    distanceInput.name = 'estimated_distance';
    distanceInput.value = distance || 0;
    form.appendChild(distanceInput);
    
    var durationInput = document.createElement('input');
    durationInput.type = 'hidden';
    durationInput.name = 'estimated_duration';
    durationInput.value = duration || 0;
    form.appendChild(durationInput);
    
    var calculateInput = document.createElement('input');
    calculateInput.type = 'hidden';
    calculateInput.name = 'calculate_estimate';
    calculateInput.value = '1';
    form.appendChild(calculateInput);
    
    document.body.appendChild(form);
    form.submit();
}

// Preview fare before ending trip
function previewFare() {
    var distance = document.getElementById('distance').value;
    var duration = document.getElementById('duration').value;
    
    if (distance && distance > 0) {
        // Make AJAX call to calculate fare preview
        fetch('calculate_fare_preview.php?distance=' + distance + '&duration=' + (duration || 0))
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    document.getElementById('farePreview').style.display = 'block';
                    document.getElementById('previewDetails').innerHTML = `
                        Distance: ${data.distance} km<br>
                        Duration: ${data.duration} min<br>
                        <strong>Estimated Fare: KES ${data.fare.toLocaleString()}</strong>
                    `;
                }
            })
            .catch(error => console.log('Error:', error));
    }
}

// Validate end trip form
function validateEndTrip() {
    var distance = document.getElementById('distance').value;
    var endLocation = document.getElementById('end_location').value;
    
    if (!endLocation) {
        alert('Please enter end location');
        return false;
    }
    if (!distance || distance <= 0) {
        alert('Please enter actual distance traveled');
        return false;
    }
    return confirm('End this trip? The fare will be calculated based on the distance and duration provided.');
}

// Auto-preview when distance changes
document.getElementById('distance')?.addEventListener('input', function() {
    if (this.value && this.value > 0) {
        clearTimeout(window.previewTimeout);
        window.previewTimeout = setTimeout(previewFare, 500);
    }
});

document.getElementById('duration')?.addEventListener('input', function() {
    if (document.getElementById('distance').value > 0) {
        clearTimeout(window.previewTimeout);
        window.previewTimeout = setTimeout(previewFare, 500);
    }
});
</script>

<?php include '../includes/footer.php'; ?>