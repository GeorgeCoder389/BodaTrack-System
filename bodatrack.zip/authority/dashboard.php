<?php
require_once '../config/db.php';
requireRole('authority');

// Get statistics
$total_riders = $pdo->query("SELECT COUNT(*) FROM riders WHERE status = 'active'")->fetchColumn();
$total_trips = $pdo->query("SELECT COUNT(*) FROM trips WHERE status = 'completed'")->fetchColumn();
$total_saccos = $pdo->query("SELECT COUNT(*) FROM saccos")->fetchColumn();

// Emergency alerts
$emergency_alerts = $pdo->query("
    SELECT a.*, u.full_name as rider_name, s.name as sacco_name 
    FROM alerts a 
    LEFT JOIN riders r ON a.rider_id = r.id 
    LEFT JOIN users u ON r.user_id = u.id 
    LEFT JOIN saccos s ON r.sacco_id = s.id 
    WHERE a.type = 'emergency' AND a.status != 'resolved'
    ORDER BY a.created_at DESC 
    LIMIT 10
")->fetchAll();

// Recent trips
$recent_trips = $pdo->query("
    SELECT t.*, u.full_name as rider_name, s.name as sacco_name 
    FROM trips t 
    JOIN riders r ON t.rider_id = r.id 
    JOIN users u ON r.user_id = u.id 
    JOIN saccos s ON r.sacco_id = s.id 
    ORDER BY t.created_at DESC 
    LIMIT 10
")->fetchAll();

include '../includes/header.php';
include '../includes/sidebar.php';
?>

<div class="row">
    <div class="col-md-4">
        <div class="stat-card text-center">
            <i class="fas fa-users"></i>
            <h3><?php echo $total_riders; ?></h3>
            <p>Active Riders</p>
        </div>
    </div>
    <div class="col-md-4">
        <div class="stat-card text-center">
            <i class="fas fa-road"></i>
            <h3><?php echo $total_trips; ?></h3>
            <p>Completed Trips</p>
        </div>
    </div>
    <div class="col-md-4">
        <div class="stat-card text-center">
            <i class="fas fa-building"></i>
            <h3><?php echo $total_saccos; ?></h3>
            <p>Registered SACCOS</p>
        </div>
    </div>
</div>

<?php if (count($emergency_alerts) > 0): ?>
<div class="row mt-4">
    <div class="col-md-12">
        <div class="card border-danger">
            <div class="card-header bg-danger text-white">
                <h5><i class="fas fa-exclamation-triangle"></i> Active Emergency Alerts</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Rider</th>
                                <th>SACCO</th>
                                <th>Message</th>
                                <th>Time</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($emergency_alerts as $alert): ?>
                            <tr class="table-danger">
                                <td><?php echo htmlspecialchars($alert['rider_name']); ?></td>
                                <td><?php echo htmlspecialchars($alert['sacco_name']); ?></td>
                                <td><?php echo htmlspecialchars($alert['message']); ?></td>
                                <td><?php echo date('Y-m-d H:i:s', strtotime($alert['created_at'])); ?></td>
                                <td><?php echo $alert['status']; ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<div class="row mt-4">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h5><i class="fas fa-road"></i> Recent Trips</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Rider</th>
                                <th>SACCO</th>
                                <th>From</th>
                                <th>To</th>
                                <th>Time</th>
                                <th>Distance</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($recent_trips as $trip): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($trip['rider_name']); ?></td>
                                <td><?php echo htmlspecialchars($trip['sacco_name']); ?></td>
                                <td><?php echo htmlspecialchars($trip['start_location']); ?></td>
                                <td><?php echo htmlspecialchars($trip['end_location']); ?></td>
                                <td><?php echo date('Y-m-d H:i', strtotime($trip['created_at'])); ?></td>
                                <td><?php echo $trip['distance_km'] ?? '-'; ?> km</td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>