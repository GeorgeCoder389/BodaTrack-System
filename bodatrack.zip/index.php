<?php
session_start();

// If user is already logged in, redirect to their dashboard
if(isset($_SESSION['user_id'])) {
    switch($_SESSION['role']) {
        case 'admin':
            header('Location: admin/dashboard.php');
            break;
        case 'sacco_official':
            header('Location: sacco/dashboard.php');
            break;
        case 'rider':
            header('Location: rider/dashboard.php');
            break;
        case 'authority':
            header('Location: authority/dashboard.php');
            break;
        default:
            header('Location: login.php');
    }
    exit();
} else {
    // Not logged in, go to login page
    header('Location: login.php');
    exit();
}
?>