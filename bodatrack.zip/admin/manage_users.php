<?php
require_once '../config/db.php';
requireRole('admin');

$message = '';
$error = '';
$edit_user = null;

// EDIT USER
if (isset($_GET['edit'])) {
    $id = $_GET['edit'];
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$id]);
    $edit_user = $stmt->fetch();
}

// UPDATE USER
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_user'])) {
    $user_id = $_POST['user_id'];
    $full_name = trim($_POST['full_name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $role = $_POST['role'];
    $sacco_id = ($role == 'sacco_official' || $role == 'rider') ? $_POST['sacco_id'] : null;
    
    try {
        $stmt = $pdo->prepare("UPDATE users SET full_name = ?, email = ?, phone = ?, role = ?, sacco_id = ? WHERE id = ?");
        $stmt->execute([$full_name, $email, $phone, $role, $sacco_id, $user_id]);
        
        if (!empty($_POST['password'])) {
            $new_password = password_hash($_POST['password'], PASSWORD_DEFAULT);
            $stmt2 = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
            $stmt2->execute([$new_password, $user_id]);
        }
        
        $message = "✅ User updated successfully!";
        logActivity($_SESSION['user_id'], "Updated user ID: $user_id");
        $edit_user = null;
    } catch (PDOException $e) {
        $error = "Update failed: " . $e->getMessage();
    }
}

// DELETE USER
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    try {
        $stmt = $pdo->prepare("DELETE FROM riders WHERE user_id = ?");
        $stmt->execute([$id]);
        $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
        $stmt->execute([$id]);
        $message = "✅ User deleted successfully!";
        logActivity($_SESSION['user_id'], "Deleted user ID: $id");
    } catch (PDOException $e) {
        $error = "Cannot delete user with existing records";
    }
}

// TOGGLE USER STATUS
if (isset($_GET['toggle'])) {
    $id = $_GET['toggle'];
    $stmt = $pdo->prepare("UPDATE users SET status = IF(status = 'active', 'inactive', 'active') WHERE id = ?");
    $stmt->execute([$id]);
    $message = "✅ User status updated";
}

// ADD NEW USER
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_user'])) {
    $username = trim($_POST['username']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $full_name = trim($_POST['full_name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $role = $_POST['role'];
    $sacco_id = ($role == 'sacco_official' || $role == 'rider') ? $_POST['sacco_id'] : null;
    
    try {
        $stmt = $pdo->prepare("INSERT INTO users (username, password, full_name, email, phone, role, sacco_id, status) VALUES (?, ?, ?, ?, ?, ?, ?, 'active')");
        $stmt->execute([$username, $password, $full_name, $email, $phone, $role, $sacco_id]);
        
        if ($role == 'rider' && $sacco_id) {
            $user_id = $pdo->lastInsertId();
            $stmt2 = $pdo->prepare("INSERT INTO riders (user_id, sacco_id, status) VALUES (?, ?, 'pending')");
            $stmt2->execute([$user_id, $sacco_id]);
        }
        
        $message = "✅ User added successfully";
        logActivity($_SESSION['user_id'], "Added new user: $username");
    } catch (PDOException $e) {
        $error = "Username or email already exists";
    }
}

// GET ALL USERS
$users = $pdo->query("
    SELECT u.*, s.name as sacco_name 
    FROM users u 
    LEFT JOIN saccos s ON u.sacco_id = s.id 
    ORDER BY 
        CASE WHEN u.role = 'admin' THEN 0 ELSE 1 END,
        u.created_at DESC
")->fetchAll();

$saccos = $pdo->query("SELECT id, name, location FROM saccos ORDER BY name")->fetchAll();

include '../includes/header.php';
include '../includes/sidebar.php';
?>

<div class="row">
    <div class="col-md-5">
        <!-- ADD NEW USER FORM -->
        <div class="card mb-3">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0"><i class="fas fa-user-plus"></i> Add New User</h5>
            </div>
            <div class="card-body">
                <?php if ($message): ?>
                    <div class="alert alert-success alert-dismissible fade show">
                        <?php echo $message; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                <?php if ($error): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>
                
                <form method="POST" id="addUserForm">
                    <input type="hidden" name="add_user" value="1">
                    
                    <div class="mb-3">
                        <label class="form-label">Username *</label>
                        <input type="text" name="username" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Password *</label>
                        <input type="password" name="password" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Full Name *</label>
                        <input type="text" name="full_name" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Email *</label>
                        <input type="email" name="email" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Phone</label>
                        <input type="text" name="phone" class="form-control" placeholder="e.g., 0712345678">
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Role *</label>
                        <select name="role" id="role_select" class="form-control" required>
                            <option value="">-- Select Role --</option>
                            <option value="admin">System Administrator</option>
                            <option value="sacco_official">SACCO Official</option>
                            <option value="authority">Authority / Regulator</option>
                            <option value="rider">Rider</option>
                        </select>
                    </div>
                    
                    <div class="mb-3" id="sacco_div" style="display:none;">
                        <label class="form-label"><i class="fas fa-building"></i> Assign to SACCO *</label>
                        <select name="sacco_id" class="form-control">
                            <option value="">-- Select SACCO --</option>
                            <?php foreach ($saccos as $sacco): ?>
                                <option value="<?php echo $sacco['id']; ?>">
                                    <?php echo htmlspecialchars($sacco['name']); ?> (<?php echo htmlspecialchars($sacco['location']); ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <small class="text-muted">Required for SACCO Officials and Riders</small>
                    </div>
                    
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-save"></i> Create User
                    </button>
                </form>
            </div>
        </div>
        
        <!-- EDIT USER FORM -->
        <?php if ($edit_user): ?>
        <div class="card mb-3 border-warning">
            <div class="card-header bg-warning">
                <h5 class="mb-0"><i class="fas fa-edit"></i> Edit User: <?php echo htmlspecialchars($edit_user['username']); ?></h5>
            </div>
            <div class="card-body">
                <form method="POST">
                    <input type="hidden" name="update_user" value="1">
                    <input type="hidden" name="user_id" value="<?php echo $edit_user['id']; ?>">
                    
                    <div class="mb-3">
                        <label class="form-label">Username</label>
                        <input type="text" class="form-control" value="<?php echo htmlspecialchars($edit_user['username']); ?>" disabled>
                        <small class="text-muted">Username cannot be changed</small>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">New Password (optional)</label>
                        <input type="password" name="password" class="form-control" placeholder="Leave blank to keep current password">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Full Name *</label>
                        <input type="text" name="full_name" class="form-control" value="<?php echo htmlspecialchars($edit_user['full_name']); ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Email *</label>
                        <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($edit_user['email']); ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Phone</label>
                        <input type="text" name="phone" class="form-control" value="<?php echo htmlspecialchars($edit_user['phone']); ?>">
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Role *</label>
                        <select name="role" id="edit_role_select" class="form-control" required>
                            <option value="admin" <?php echo $edit_user['role'] == 'admin' ? 'selected' : ''; ?>>Administrator</option>
                            <option value="sacco_official" <?php echo $edit_user['role'] == 'sacco_official' ? 'selected' : ''; ?>>SACCO Official</option>
                            <option value="authority" <?php echo $edit_user['role'] == 'authority' ? 'selected' : ''; ?>>Authority</option>
                            <option value="rider" <?php echo $edit_user['role'] == 'rider' ? 'selected' : ''; ?>>Rider</option>
                        </select>
                    </div>
                    
                    <div class="mb-3" id="edit_sacco_div" style="display: <?php echo ($edit_user['role'] == 'sacco_official' || $edit_user['role'] == 'rider') ? 'block' : 'none'; ?>;">
                        <label class="form-label"><i class="fas fa-building"></i> Assign to SACCO</label>
                        <select name="sacco_id" class="form-control">
                            <option value="">-- Select SACCO --</option>
                            <?php foreach ($saccos as $sacco): ?>
                                <option value="<?php echo $sacco['id']; ?>" <?php echo $edit_user['sacco_id'] == $sacco['id'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($sacco['name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-success flex-grow-1">
                            <i class="fas fa-save"></i> Update User
                        </button>
                        <a href="manage_users.php" class="btn btn-secondary">
                            <i class="fas fa-times"></i> Cancel
                        </a>
                    </div>
                </form>
            </div>
        </div>
        <?php endif; ?>
    </div>
    
    <div class="col-md-7">
        <!-- USERS LIST TABLE -->
        <div class="card">
            <div class="card-header bg-dark text-white">
                <h5 class="mb-0"><i class="fas fa-users"></i> All System Users</h5>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover table-bordered mb-0">
                        <thead class="table-dark">
                            <tr>
                                <th>Username</th>
                                <th>Full Name</th>
                                <th>Role</th>
                                <th>SACCO</th>
                                <th>Status</th>
                                <th style="width: 180px;">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($users as $user): ?>
                            <tr>
                                <td>
                                    <?php echo htmlspecialchars($user['username']); ?>
                                    <?php if ($user['role'] == 'admin'): ?>
                                        <span class="badge bg-danger ms-1">Admin</span>
                                    <?php endif; ?>
                                    <?php if (($user['role'] == 'sacco_official' || $user['role'] == 'rider') && !$user['sacco_id']): ?>
                                        <span class="badge bg-warning ms-1">No SACCO</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo htmlspecialchars($user['full_name']); ?></td>
                                <td>
                                    <span class="badge bg-<?php 
                                        echo $user['role'] == 'admin' ? 'danger' : 
                                            ($user['role'] == 'sacco_official' ? 'primary' : 
                                            ($user['role'] == 'authority' ? 'info' : 'success')); 
                                    ?>">
                                        <?php echo ucfirst(str_replace('_', ' ', $user['role'])); ?>
                                    </span>
                                </td>
                                <td>
                                    <?php if ($user['role'] == 'admin'): ?>
                                        <span class="text-muted">-</span>
                                    <?php elseif ($user['sacco_name']): ?>
                                        <span class="badge bg-primary"><?php echo htmlspecialchars($user['sacco_name']); ?></span>
                                    <?php else: ?>
                                        <span class="badge bg-danger">Not Assigned!</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="badge bg-<?php echo $user['status'] == 'active' ? 'success' : 'secondary'; ?>">
                                        <?php echo ucfirst($user['status']); ?>
                                    </span>
                                </td>
                                <td class="text-nowrap">
                                    <a href="?edit=<?php echo $user['id']; ?>" class="btn btn-sm btn-primary" title="Edit User">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <a href="?toggle=<?php echo $user['id']; ?>" class="btn btn-sm btn-warning" title="Toggle Status">
                                        <i class="fas fa-toggle-<?php echo $user['status'] == 'active' ? 'on' : 'off'; ?>"></i>
                                    </a>
                                    <a href="?delete=<?php echo $user['id']; ?>" class="btn btn-sm btn-danger" title="Delete User" onclick="return confirm('Delete this user permanently?')">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// For Add User Form
var roleSelect = document.getElementById('role_select');
var saccoDiv = document.getElementById('sacco_div');

if (roleSelect) {
    roleSelect.addEventListener('change', function() {
        if (this.value === 'sacco_official' || this.value === 'rider') {
            saccoDiv.style.display = 'block';
        } else {
            saccoDiv.style.display = 'none';
        }
    });
}

// For Edit User Form
var editRoleSelect = document.getElementById('edit_role_select');
var editSaccoDiv = document.getElementById('edit_sacco_div');

if (editRoleSelect) {
    editRoleSelect.addEventListener('change', function() {
        if (this.value === 'sacco_official' || this.value === 'rider') {
            editSaccoDiv.style.display = 'block';
        } else {
            editSaccoDiv.style.display = 'none';
        }
    });
}
</script>

<?php include '../includes/footer.php'; ?>