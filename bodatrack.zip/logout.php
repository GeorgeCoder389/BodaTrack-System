<?php
require_once 'config/db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['confirm']) && $_POST['confirm'] == 'yes') {
    if (isset($_SESSION['user_id'])) {
        logActivity($_SESSION['user_id'], "User logged out: " . ($_SESSION['username'] ?? 'Unknown'));
    }
    
    $_SESSION = array();
    
    if (isset($_COOKIE[session_name()])) {
        setcookie(session_name(), '', time()-3600, '/');
    }
    
    session_destroy();
    session_start();
    $_SESSION['logout_message'] = '✓ You have been successfully logged out. Thank you for using BodaTrack!';
    $_SESSION['logout_message_type'] = 'success';
    session_write_close();
    
    header('Location: login.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logout - BodaTrack</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; font-family: 'Segoe UI', sans-serif; }
        .logout-container { max-width: 500px; margin: 0 auto; padding: 20px; }
        .logout-card { background: white; border-radius: 20px; padding: 40px; text-align: center; box-shadow: 0 20px 60px rgba(0,0,0,0.3); animation: fadeInUp 0.5s ease; }
        @keyframes fadeInUp { from { opacity: 0; transform: translateY(30px); } to { opacity: 1; transform: translateY(0); } }
        .logout-icon { font-size: 80px; color: #f44336; margin-bottom: 20px; animation: pulse 1.5s ease infinite; }
        @keyframes pulse { 0%, 100% { transform: scale(1); } 50% { transform: scale(1.1); } }
        h2 { color: #333; margin-bottom: 15px; }
        .user-info { background: #f5f5f5; padding: 15px; border-radius: 10px; margin: 20px 0; }
        .user-info strong { color: #667eea; }
        .warning-message { background: #fff3e0; border-left: 4px solid #ff9800; padding: 15px; border-radius: 10px; margin: 20px 0; text-align: left; }
        .btn-group { display: flex; gap: 15px; margin-top: 25px; }
        .btn { flex: 1; padding: 12px; border: none; border-radius: 10px; font-size: 16px; font-weight: bold; cursor: pointer; transition: all 0.3s; }
        .btn-logout { background: linear-gradient(135deg, #f44336 0%, #d32f2f 100%); color: white; }
        .btn-logout:hover { transform: translateY(-2px); box-shadow: 0 5px 20px rgba(244,67,54,0.4); }
        .btn-cancel { background: #e0e0e0; color: #333; }
        .btn-cancel:hover { background: #bdbdbd; transform: translateY(-2px); }
        .footer { margin-top: 20px; font-size: 12px; color: #999; }
    </style>
</head>
<body>
    <div class="d-flex justify-content-center align-items-center min-vh-100">
        <div class="logout-container">
            <div class="logout-card">
                <div class="logout-icon"><i class="fas fa-sign-out-alt"></i></div>
                <h2>Ready to Leave?</h2>
                <p style="color: #666;">Are you sure you want to logout?</p>
                
                <div class="user-info">
                    <p><i class="fas fa-user"></i> Logged in as: <strong><?php echo htmlspecialchars($_SESSION['full_name'] ?? 'User'); ?></strong></p>
                    <p><i class="fas fa-tag"></i> Role: <strong><?php echo ucfirst($_SESSION['role'] ?? 'Unknown'); ?></strong></p>
                </div>
                
                <div class="warning-message">
                    <i class="fas fa-info-circle"></i> <small>You will need to login again to access your account.</small>
                </div>
                
                <form method="POST">
                    <div class="btn-group">
                        <button type="submit" name="confirm" value="yes" class="btn btn-logout">
                            <i class="fas fa-check-circle"></i> Yes, Logout
                        </button>
                        <button type="button" class="btn btn-cancel" onclick="window.history.back()">
                            <i class="fas fa-times-circle"></i> Cancel
                        </button>
                    </div>
                </form>
                
                <div class="footer"><i class="fas fa-shield-alt"></i> BodaTrack Secure System</div>
            </div>
        </div>
    </div>
</body>
</html>