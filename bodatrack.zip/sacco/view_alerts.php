<?php
require_once '../config/db.php';
requireRole('sacco_official');

$sacco_id = $_SESSION['sacco_id'];

// Mark alert as read
if (isset($_GET['read'])) {
    $stmt = $pdo->prepare("UPDATE alerts SET status = 'read' WHERE id = ?");
    $stmt->execute([$_GET['read']]);
    header('Location: view_alerts.php');
    exit();
}

$alerts = $pdo->prepare("
    SELECT a.*, u.full_name as rider_name 
    FROM alerts a 
    LEFT JOIN riders r ON a.rider_id = r.id 
    LEFT JOIN users u ON r.user_id = u.id 
    WHERE a.sacco_id = ? OR a.rider_id IS NULL
    ORDER BY a.created_at DESC 
    LIMIT 50
");
$alerts->execute([$sacco_id]);
$alerts = $alerts->fetchAll();

include '../includes/header.php';
include '../includes/sidebar.php';
?>

<div class="card">
    <div class="card-header">
        <h5><i class="fas fa-bell"></i> SACCO Alerts</h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Type</th>
                        <th>Severity</th>
                        <th>Message</th>
                        <th>Rider</th>
                        <th>Date</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($alerts as $alert): ?>
                    <tr class="<?php echo $alert['status'] == 'unread' ? 'table-warning' : ''; ?>">
                        <td>
                            <span class="badge bg-<?php 
                                echo $alert['type'] == 'emergency' ? 'danger' : 
                                    ($alert['type'] == 'document_expiry' ? 'warning' : 'info'); 
                            ?>">
                                <?php echo $alert['type']; ?>
                            </span>
                        </td>
                        <td>
                            <span class="badge bg-<?php 
                                echo $alert['severity'] == 'critical' ? 'danger' : 
                                    ($alert['severity'] == 'high' ? 'warning' : 'secondary'); 
                            ?>">
                                <?php echo $alert['severity']; ?>
                            </span>
                        </td>
                        <td><?php echo htmlspecialchars($alert['message']); ?></td>
                        <td><?php echo htmlspecialchars($alert['rider_name'] ?? 'System'); ?></td>
                        <td><?php echo date('Y-m-d H:i', strtotime($alert['created_at'])); ?></td>
                        <td><?php echo $alert['status']; ?></td>
                        <td>
                            <?php if ($alert['status'] == 'unread'): ?>
                                <a href="?read=<?php echo $alert['id']; ?>" class="btn btn-sm btn-info">Mark Read</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>