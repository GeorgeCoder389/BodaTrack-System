<?php
require_once '../config/db.php';
requireRole('rider');

$stmt = $pdo->prepare("SELECT id, sacco_id FROM riders WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$rider = $stmt->fetch();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $message = "EMERGENCY ALERT from rider " . $_SESSION['full_name'] . ": " . $_POST['message'];
    
    $stmt = $pdo->prepare("INSERT INTO alerts (type, severity, message, rider_id, sacco_id, status) VALUES ('emergency', 'critical', ?, ?, ?, 'unread')");
    if ($stmt->execute([$message, $rider['id'], $rider['sacco_id']])) {
        logActivity($_SESSION['user_id'], "Triggered emergency alert");
        $success = "Emergency alert sent! Authorities have been notified.";
    }
}

include '../includes/header.php';
include '../includes/sidebar.php';
?>

<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card">
            <div class="card-header bg-danger text-white">
                <h5><i class="fas fa-exclamation-triangle"></i> Emergency Alert</h5>
            </div>
            <div class="card-body text-center">
                <?php if (isset($success)): ?>
                    <div class="alert alert-success"><?php echo $success; ?></div>
                <?php endif; ?>
                
                <div class="alert alert-warning">
                    <i class="fas fa-info-circle"></i> Only use this for real emergencies!
                </div>
                
                <form method="POST">
                    <div class="mb-3">
                        <label>Describe your emergency</label>
                        <textarea name="message" class="form-control" rows="3" required placeholder="e.g., Accident at Junction A, need medical assistance"></textarea>
                    </div>
                    <button type="submit" class="btn btn-danger btn-lg" onclick="return confirm('Are you sure you want to send an emergency alert?')">
                        <i class="fas fa-bell"></i> Send Emergency Alert
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>