<?php
require_once '../config/db.php';
requireRole('rider');

// Get rider ID
$stmt = $pdo->prepare("SELECT id FROM riders WHERE user_id = ? AND status = 'active'");
$stmt->execute([$_SESSION['user_id']]);
$rider = $stmt->fetch();

if (!$rider) {
    header('Location: dashboard.php');
    exit();
}

$rider_id = $rider['id'];
$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $latitude = $_POST['latitude'];
    $longitude = $_POST['longitude'];
    $location_name = $_POST['location_name'] ?? '';
    
    $stmt = $pdo->prepare("INSERT INTO gps_logs (rider_id, latitude, longitude, location_name) VALUES (?, ?, ?, ?)");
    if ($stmt->execute([$rider_id, $latitude, $longitude, $location_name])) {
        $success = "Location updated successfully!";
        logActivity($_SESSION['user_id'], "Updated GPS location");
    } else {
        $error = "Failed to update location";
    }
}

// Get last 10 locations
$locations = $pdo->prepare("SELECT * FROM gps_logs WHERE rider_id = ? ORDER BY recorded_at DESC LIMIT 10");
$locations->execute([$rider_id]);
$locations = $locations->fetchAll();

include '../includes/header.php';
include '../includes/sidebar.php';
?>

<div class="row">
    <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                <h5><i class="fas fa-map-marker-alt"></i> Update Current Location</h5>
            </div>
            <div class="card-body">
                <?php if ($success): ?>
                    <div class="alert alert-success"><?php echo $success; ?></div>
                <?php endif; ?>
                <?php if ($error): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>
                
                <button onclick="getLocation()" class="btn btn-primary mb-3">
                    <i class="fas fa-location-dot"></i> Get Current Location
                </button>
                
                <form method="POST" id="locationForm">
                    <div class="mb-3">
                        <label>Latitude</label>
                        <input type="text" name="latitude" id="latitude" class="form-control" readonly required>
                    </div>
                    <div class="mb-3">
                        <label>Longitude</label>
                        <input type="text" name="longitude" id="longitude" class="form-control" readonly required>
                    </div>
                    <div class="mb-3">
                        <label>Location Name (Optional)</label>
                        <input type="text" name="location_name" class="form-control" placeholder="e.g., CBD, Westlands">
                    </div>
                    <button type="submit" class="btn btn-success">Save Location</button>
                </form>
            </div>
        </div>
    </div>
    
    <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                <h5><i class="fas fa-history"></i> Recent Location History</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-sm">
                        <thead>
                            <tr>
                                <th>Location</th>
                                <th>Coordinates</th>
                                <th>Time</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($locations as $loc): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($loc['location_name'] ?: 'N/A'); ?></td>
                                <td><?php echo $loc['latitude'] . ', ' . $loc['longitude']; ?></td>
                                <td><?php echo date('H:i:s', strtotime($loc['recorded_at'])); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function getLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(showPosition, showError);
    } else {
        alert("Geolocation is not supported by this browser.");
    }
}

function showPosition(position) {
    document.getElementById('latitude').value = position.coords.latitude;
    document.getElementById('longitude').value = position.coords.longitude;
}

function showError(error) {
    switch(error.code) {
        case error.PERMISSION_DENIED:
            alert("Please allow location access to use this feature.");
            break;
        case error.POSITION_UNAVAILABLE:
            alert("Location information is unavailable.");
            break;
        case error.TIMEOUT:
            alert("The request to get user location timed out.");
            break;
    }
}
</script>

<?php include '../includes/footer.php'; ?>