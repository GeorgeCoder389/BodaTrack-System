<?php
require_once '../config/db.php';
requireRole('rider');

$welcome_message = '';
if (isset($_SESSION['just_logged_in'])) {
    $welcome_message = "Welcome back, " . $_SESSION['full_name'] . "! You have successfully logged in.";
    unset($_SESSION['just_logged_in']);
}

// Get rider ID - FIXED with better error handling
$stmt = $pdo->prepare("SELECT id, status FROM riders WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$rider = $stmt->fetch();

// Initialize variables with defaults
$rider_id = 0;
$total_trips = 0;
$completed_trips = 0;
$ongoing_trip = null;
$unread_alerts = 0;
$recent_trips = [];

if ($rider && isset($rider['id'])) {
    $rider_id = $rider['id'];
    $rider_status = $rider['status'];
    
    // Get statistics only if rider exists
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM trips WHERE rider_id = ?");
    $stmt->execute([$rider_id]);
    $total_trips = $stmt->fetchColumn();
    
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM trips WHERE rider_id = ? AND status = 'completed'");
    $stmt->execute([$rider_id]);
    $completed_trips = $stmt->fetchColumn();
    
    $stmt = $pdo->prepare("SELECT * FROM trips WHERE rider_id = ? AND status = 'ongoing'");
    $stmt->execute([$rider_id]);
    $ongoing_trip = $stmt->fetch();
    
    $stmt = $pdo->prepare("
        SELECT COUNT(*) FROM alerts a 
        JOIN riders r ON a.rider_id = r.id 
        WHERE r.id = ? AND a.status = 'unread'
    ");
    $stmt->execute([$rider_id]);
    $unread_alerts = $stmt->fetchColumn();
    
    $stmt = $pdo->prepare("
        SELECT * FROM trips 
        WHERE rider_id = ? 
        ORDER BY created_at DESC 
        LIMIT 5
    ");
    $stmt->execute([$rider_id]);
    $recent_trips = $stmt->fetchAll();
} else {
    $rider_status = 'not_registered';
}

include '../includes/header.php';
include '../includes/sidebar.php';
?>

<?php if ($welcome_message): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <i class="fas fa-smile-wink"></i> <?php echo $welcome_message; ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<?php if ($rider_status == 'pending'): ?>
    <div class="alert alert-warning">
        <i class="fas fa-clock"></i> Your account is pending approval. You will be able to start trips once approved by your SACCO.
    </div>
<?php elseif ($rider_status == 'not_registered'): ?>
    <div class="alert alert-danger">
        <i class="fas fa-exclamation-triangle"></i> Your rider profile is not fully set up. Please contact your SACCO administrator.
    </div>
<?php endif; ?>

<div class="row">
    <div class="col-md-3">
        <div class="stat-card text-center">
            <i class="fas fa-road"></i>
            <h3><?php echo $total_trips; ?></h3>
            <p>Total Trips</p>
        </div>
    </div>
    <div class="col-md-3">
        <div class="stat-card text-center">
            <i class="fas fa-check-circle"></i>
            <h3><?php echo $completed_trips; ?></h3>
            <p>Completed Trips</p>
        </div>
    </div>
    <div class="col-md-3">
        <div class="stat-card text-center">
            <i class="fas fa-play-circle"></i>
            <h3><?php echo $ongoing_trip ? '1' : '0'; ?></h3>
            <p>Active Trip</p>
        </div>
    </div>
    <div class="col-md-3">
        <div class="stat-card text-center">
            <i class="fas fa-bell"></i>
            <h3><?php echo $unread_alerts; ?></h3>
            <p>Unread Alerts</p>
        </div>
    </div>
</div>

<?php if ($ongoing_trip): ?>
<div class="row mt-3">
    <div class="col-md-12">
        <div class="alert alert-info">
            <strong><i class="fas fa-motorcycle"></i> Trip in Progress!</strong>
            Started at: <?php echo date('H:i:s', strtotime($ongoing_trip['start_time'])); ?> 
            from <?php echo htmlspecialchars($ongoing_trip['start_location']); ?>
            <a href="manage_trips.php" class="btn btn-sm btn-primary float-end">End Trip</a>
        </div>
    </div>
</div>
<?php endif; ?>

<div class="row mt-4">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h5>Recent Trips</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Start Location</th>
                                <th>End Location</th>
                                <th>Distance</th>
                                <th>Fare</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (count($recent_trips) > 0): ?>
                                <?php foreach ($recent_trips as $trip): ?>
                                <tr>
                                    <td><?php echo date('Y-m-d H:i', strtotime($trip['created_at'])); ?></td>
                                    <td><?php echo htmlspecialchars($trip['start_location']); ?></td>
                                    <td><?php echo htmlspecialchars($trip['end_location'] ?? '-'); ?></td>
                                    <td><?php echo $trip['distance_km'] ?? '-'; ?> km</td>
                                    <td><?php echo $trip['fare'] ? 'KES ' . number_format($trip['fare']) : '-'; ?></td>
                                    <td>
                                        <span class="badge bg-<?php 
                                            echo $trip['status'] == 'completed' ? 'success' : 
                                                ($trip['status'] == 'ongoing' ? 'primary' : 'danger'); 
                                        ?>">
                                            <?php echo $trip['status']; ?>
                                        </span>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="6" class="text-center">No trips yet. Start your first trip!</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>