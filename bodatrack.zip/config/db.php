<?php
session_start();

$host = 'localhost';
$dbname = 'bodatrack';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function hasRole($role) {
    return isset($_SESSION['role']) && $_SESSION['role'] == $role;
}

function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: ../login.php');
        exit();
    }
}

function requireRole($role) {
    requireLogin();
    if (!hasRole($role)) {
        header('Location: ../index.php');
        exit();
    }
}

function logActivity($user_id, $action, $details = null) {
    global $pdo;
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $stmt = $pdo->prepare("INSERT INTO system_logs (user_id, action, details, ip_address) VALUES (?, ?, ?, ?)");
    $stmt->execute([$user_id, $action, $details, $ip]);
}

function checkDocumentExpiry() {
    global $pdo;
    
    $stmt = $pdo->prepare("
        SELECT r.id as rider_id, r.user_id, u.full_name, r.license_expiry, r.sacco_id 
        FROM riders r 
        JOIN users u ON r.user_id = u.id 
        WHERE r.license_expiry IS NOT NULL 
        AND r.status = 'active'
        AND u.status = 'active'
        AND DATEDIFF(r.license_expiry, CURDATE()) BETWEEN 0 AND 31
    ");
    $stmt->execute();
    $expiring = $stmt->fetchAll();
    
    foreach ($expiring as $rider) {
        $days = (new DateTime($rider['license_expiry']))->diff(new DateTime())->days;
        $message = "Rider {$rider['full_name']}'s license expires in $days days.";
        
        $check = $pdo->prepare("SELECT id FROM alerts WHERE rider_id = ? AND type = 'document_expiry' AND DATE(created_at) = CURDATE()");
        $check->execute([$rider['rider_id']]);
        if (!$check->fetch()) {
            $alert = $pdo->prepare("INSERT INTO alerts (type, message, rider_id, sacco_id, severity) VALUES ('document_expiry', ?, ?, ?, 'high')");
            $alert->execute([$message, $rider['rider_id'], $rider['sacco_id']]);
        }
    }
}
?>