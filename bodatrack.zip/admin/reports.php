<?php
require_once '../config/db.php';
requireRole('admin');

// Get statistics
$total_riders = $pdo->query("SELECT COUNT(*) FROM riders")->fetchColumn();
$active_riders = $pdo->query("SELECT COUNT(*) FROM riders WHERE status = 'active'")->fetchColumn();
$pending_riders = $pdo->query("SELECT COUNT(*) FROM riders WHERE status = 'pending'")->fetchColumn();

$total_trips = $pdo->query("SELECT COUNT(*) FROM trips")->fetchColumn();
$completed_trips = $pdo->query("SELECT COUNT(*) FROM trips WHERE status = 'completed'")->fetchColumn();

// Monthly trips
$monthly_trips = $pdo->query("
    SELECT DATE_FORMAT(created_at, '%Y-%m') as month, COUNT(*) as count 
    FROM trips 
    WHERE created_at >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
    GROUP BY DATE_FORMAT(created_at, '%Y-%m')
    ORDER BY month DESC
")->fetchAll();

// Riders by SACCO
$riders_by_sacco = $pdo->query("
    SELECT s.name, COUNT(r.id) as count 
    FROM saccos s 
    LEFT JOIN riders r ON s.id = r.sacco_id 
    GROUP BY s.id
")->fetchAll();

include '../includes/header.php';
include '../includes/sidebar.php';
?>

<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h5><i class="fas fa-chart-bar"></i> System Reports</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <h6>Rider Statistics</h6>
                        <table class="table table-bordered">
                            <tr>
                                <th>Total Riders</th>
                                <td><?php echo $total_riders; ?></td>
                            </tr>
                            <tr>
                                <th>Active Riders</th>
                                <td><?php echo $active_riders; ?></td>
                            </tr>
                            <tr>
                                <th>Pending Approval</th>
                                <td><?php echo $pending_riders; ?></td>
                            </tr>
                        </table>
                    </div>
                    <div class="col-md-6">
                        <h6>Trip Statistics</h6>
                        <table class="table table-bordered">
                            <tr>
                                <th>Total Trips</th>
                                <td><?php echo $total_trips; ?></td>
                            </tr>
                            <tr>
                                <th>Completed Trips</th>
                                <td><?php echo $completed_trips; ?></td>
                            </tr>
                        </table>
                    </div>
                </div>
                
                <div class="row mt-4">
                    <div class="col-md-6">
                        <h6>Monthly Trips (Last 6 Months)</h6>
                        <table class="table table-bordered">
                            <thead>
                                <tr><th>Month</th><th>Trips</th></tr>
                            </thead>
                            <tbody>
                                <?php foreach ($monthly_trips as $month): ?>
                                <tr>
                                    <td><?php echo $month['month']; ?></td>
                                    <td><?php echo $month['count']; ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="col-md-6">
                        <h6>Riders per SACCO</h6>
                        <table class="table table-bordered">
                            <thead>
                                <tr><th>SACCO</th><th>Riders</th></tr>
                            </thead>
                            <tbody>
                                <?php foreach ($riders_by_sacco as $sacco): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($sacco['name']); ?></td>
                                    <td><?php echo $sacco['count']; ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>