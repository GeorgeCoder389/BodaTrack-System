<?php
require_once '../config/db.php';
requireRole('sacco_official');

$sacco_id = $_SESSION['sacco_id'];
$message = '';
$error = '';

// Handle rider deletion
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $stmt = $pdo->prepare("DELETE FROM riders WHERE id = ? AND sacco_id = ?");
    if ($stmt->execute([$id, $sacco_id])) {
        $message = "Rider deleted successfully";
        logActivity($_SESSION['user_id'], "Deleted rider ID: $id");
    }
}

// Get all riders for this SACCO
$riders = $pdo->prepare("
    SELECT r.*, u.full_name, u.email, u.phone, u.username 
    FROM riders r 
    JOIN users u ON r.user_id = u.id 
    WHERE r.sacco_id = ? 
    ORDER BY r.created_at DESC
");
$riders->execute([$sacco_id]);
$riders = $riders->fetchAll();

include '../includes/header.php';
include '../includes/sidebar.php';
?>

<div class="card">
    <div class="card-header">
        <h5><i class="fas fa-id-card"></i> Manage Riders</h5>
    </div>
    <div class="card-body">
        <?php if ($message): ?>
            <div class="alert alert-success"><?php echo $message; ?></div>
        <?php endif; ?>
        
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Username</th>
                        <th>Full Name</th>
                        <th>Email/Phone</th>
                        <th>License #</th>
                        <th>License Expiry</th>
                        <th>Insurance Expiry</th>
                        <th>Motorcycle</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($riders as $rider): ?>
                    <tr>
                        <td><?php echo $rider['id']; ?></td>
                        <td><?php echo htmlspecialchars($rider['username']); ?></td>
                        <td><?php echo htmlspecialchars($rider['full_name']); ?></td>
                        <td>
                            <?php echo htmlspecialchars($rider['email']); ?><br>
                            <small><?php echo htmlspecialchars($rider['phone']); ?></small>
                        </td>
                        <td><?php echo htmlspecialchars($rider['license_number']); ?></td>
                        <td class="<?php echo $rider['license_expiry'] && strtotime($rider['license_expiry']) < strtotime('+30 days') ? 'text-danger' : ''; ?>">
                            <?php echo $rider['license_expiry'] ? date('Y-m-d', strtotime($rider['license_expiry'])) : 'N/A'; ?>
                        </td>
                        <td class="<?php echo $rider['insurance_expiry'] && strtotime($rider['insurance_expiry']) < strtotime('+30 days') ? 'text-danger' : ''; ?>">
                            <?php echo $rider['insurance_expiry'] ? date('Y-m-d', strtotime($rider['insurance_expiry'])) : 'N/A'; ?>
                        </td>
                        <td><?php echo htmlspecialchars($rider['motorcycle_reg']); ?></td>
                        <td>
                            <span class="badge bg-<?php 
                                echo $rider['status'] == 'active' ? 'success' : 
                                    ($rider['status'] == 'pending' ? 'warning' : 'danger'); 
                            ?>">
                                <?php echo $rider['status']; ?>
                            </span>
                        </td>
                        <td>
                            <a href="?delete=<?php echo $rider['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this rider?')">
                                <i class="fas fa-trash"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>