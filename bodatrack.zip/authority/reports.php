<?php
require_once '../config/db.php';
requireRole('authority');

// Get statistics by SACCO
$sacco_stats = $pdo->query("
    SELECT 
        s.name,
        COUNT(DISTINCT r.id) as rider_count,
        COUNT(t.id) as trip_count,
        COALESCE(SUM(t.fare), 0) as total_fare,
        COALESCE(SUM(t.distance_km), 0) as total_distance
    FROM saccos s
    LEFT JOIN riders r ON s.id = r.sacco_id AND r.status = 'active'
    LEFT JOIN trips t ON r.id = t.rider_id AND t.status = 'completed'
    GROUP BY s.id
")->fetchAll();

// Monthly trends
$monthly_trends = $pdo->query("
    SELECT 
        DATE_FORMAT(created_at, '%Y-%m') as month,
        COUNT(*) as trip_count,
        COUNT(DISTINCT rider_id) as active_riders
    FROM trips 
    WHERE created_at >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
    GROUP BY DATE_FORMAT(created_at, '%Y-%m')
    ORDER BY month DESC
")->fetchAll();

include '../includes/header.php';
include '../includes/sidebar.php';
?>

<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h5><i class="fas fa-chart-bar"></i> Authority Reports</h5>
            </div>
            <div class="card-body">
                <h6>SACCO Performance Summary</h6>
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>SACCO Name</th>
                                <th>Active Riders</th>
                                <th>Total Trips</th>
                                <th>Total Distance (km)</th>
                                <th>Total Fare (KES)</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($sacco_stats as $stat): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($stat['name']); ?></td>
                                <td><?php echo $stat['rider_count']; ?></td>
                                <td><?php echo $stat['trip_count']; ?></td>
                                <td><?php echo round($stat['total_distance'], 1); ?></td>
                                <td>KES <?php echo number_format($stat['total_fare']); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                
                <h6 class="mt-4">Monthly Trends (Last 6 Months)</h6>
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Month</th>
                                <th>Total Trips</th>
                                <th>Active Riders</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($monthly_trends as $trend): ?>
                            <tr>
                                <td><?php echo $trend['month']; ?></td>
                                <td><?php echo $trend['trip_count']; ?></td>
                                <td><?php echo $trend['active_riders']; ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>