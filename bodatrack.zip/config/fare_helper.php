<?php
// Fare Calculation Helper for BodaTrack

class FareCalculator {
    private $pdo;
    private $base_fare;
    private $per_km_rate;
    private $per_minute_rate;
    private $minimum_fare;
    private $peak_hour_multiplier;
    private $night_multiplier;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
        $this->loadFareSettings();
    }
    
    private function loadFareSettings() {
        $stmt = $this->pdo->query("SELECT * FROM fare_settings ORDER BY id DESC LIMIT 1");
        $settings = $stmt->fetch();
        
        if ($settings) {
            $this->base_fare = $settings['base_fare'];
            $this->per_km_rate = $settings['per_km_rate'];
            $this->per_minute_rate = $settings['per_minute_rate'];
            $this->minimum_fare = $settings['minimum_fare'];
            $this->peak_hour_multiplier = $settings['peak_hour_multiplier'];
            $this->night_multiplier = $settings['night_multiplier'];
        } else {
            // Default values
            $this->base_fare = 50;
            $this->per_km_rate = 30;
            $this->per_minute_rate = 5;
            $this->minimum_fare = 100;
            $this->peak_hour_multiplier = 1.5;
            $this->night_multiplier = 1.3;
        }
    }
    
    // Calculate distance between two coordinates (Haversine formula)
    public function calculateDistance($lat1, $lon1, $lat2, $lon2) {
        if (!$lat1 || !$lon1 || !$lat2 || !$lon2) {
            return 0;
        }
        
        $earth_radius = 6371; // km
        
        $dLat = deg2rad($lat2 - $lat1);
        $dLon = deg2rad($lon2 - $lon1);
        
        $a = sin($dLat/2) * sin($dLat/2) +
             cos(deg2rad($lat1)) * cos(deg2rad($lat2)) *
             sin($dLon/2) * sin($dLon/2);
        
        $c = 2 * atan2(sqrt($a), sqrt(1-$a));
        $distance = $earth_radius * $c;
        
        return round($distance, 2);
    }
    
    // Get time-based multiplier (peak hours, night time)
    private function getTimeMultiplier() {
        $hour = date('H');
        
        // Night time multiplier (10 PM - 5 AM)
        if ($hour >= 22 || $hour < 5) {
            return $this->night_multiplier;
        }
        
        // Peak hours (7-9 AM and 5-7 PM)
        if (($hour >= 7 && $hour <= 9) || ($hour >= 17 && $hour <= 19)) {
            return $this->peak_hour_multiplier;
        }
        
        return 1.0;
    }
    
    // Calculate fare based on distance and duration
    public function calculateFare($distance_km, $duration_minutes = null, $apply_multiplier = true) {
        // Base calculation
        $distance_fare = $distance_km * $this->per_km_rate;
        $time_fare = ($duration_minutes ?? 0) * $this->per_minute_rate;
        
        $total_fare = $this->base_fare + $distance_fare + $time_fare;
        
        // Apply minimum fare
        if ($total_fare < $this->minimum_fare) {
            $total_fare = $this->minimum_fare;
        }
        
        // Apply time multiplier
        if ($apply_multiplier) {
            $multiplier = $this->getTimeMultiplier();
            $total_fare = $total_fare * $multiplier;
        }
        
        return round($total_fare);
    }
    
    // Get fare breakdown
    public function getFareBreakdown($distance_km, $duration_minutes = null, $apply_multiplier = true) {
        $distance_fare = $distance_km * $this->per_km_rate;
        $time_fare = ($duration_minutes ?? 0) * $this->per_minute_rate;
        $subtotal = $this->base_fare + $distance_fare + $time_fare;
        
        $multiplier = 1.0;
        $multiplier_name = "Normal";
        
        if ($apply_multiplier) {
            $multiplier = $this->getTimeMultiplier();
            if ($multiplier > 1) {
                $hour = date('H');
                if ($hour >= 22 || $hour < 5) {
                    $multiplier_name = "Night Time (10PM - 5AM)";
                } elseif (($hour >= 7 && $hour <= 9) || ($hour >= 17 && $hour <= 19)) {
                    $multiplier_name = "Peak Hour";
                }
            }
        }
        
        $total = $subtotal * $multiplier;
        if ($total < $this->minimum_fare) {
            $total = $this->minimum_fare;
        }
        
        return [
            'base_fare' => $this->base_fare,
            'distance_km' => $distance_km,
            'distance_fare' => round($distance_fare),
            'duration_minutes' => $duration_minutes,
            'time_fare' => round($time_fare),
            'subtotal' => round($subtotal),
            'multiplier' => $multiplier,
            'multiplier_name' => $multiplier_name,
            'minimum_fare' => $this->minimum_fare,
            'total_fare' => round($total)
        ];
    }
    
    // Update fare settings (Admin only)
    public function updateSettings($base_fare, $per_km_rate, $per_minute_rate, $minimum_fare, $peak_hour_multiplier, $night_multiplier, $updated_by) {
        $stmt = $this->pdo->prepare("
            INSERT INTO fare_settings (base_fare, per_km_rate, per_minute_rate, minimum_fare, peak_hour_multiplier, night_multiplier, updated_by) 
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");
        return $stmt->execute([$base_fare, $per_km_rate, $per_minute_rate, $minimum_fare, $peak_hour_multiplier, $night_multiplier, $updated_by]);
    }
    
    // Get current settings
    public function getSettings() {
        return [
            'base_fare' => $this->base_fare,
            'per_km_rate' => $this->per_km_rate,
            'per_minute_rate' => $this->per_minute_rate,
            'minimum_fare' => $this->minimum_fare,
            'peak_hour_multiplier' => $this->peak_hour_multiplier,
            'night_multiplier' => $this->night_multiplier
        ];
    }
}
?>