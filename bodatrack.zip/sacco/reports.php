<?php
require_once '../config/db.php';
requireRole('sacco_official');

$sacco_id = $_SESSION['sacco_id'];

// Get statistics
$total_riders = $pdo->prepare("SELECT COUNT(*) FROM riders WHERE sacco_id = ?");
$total_riders->execute([$sacco_id]);
$total_riders = $total_riders->fetchColumn();

$active_riders = $pdo->prepare("SELECT COUNT(*) FROM riders WHERE sacco_id = ? AND status = 'active'");
$active_riders->execute([$sacco_id]);
$active_riders = $active_riders->fetchColumn();

$total_trips = $pdo->prepare("
    SELECT COUNT(*) FROM trips t 
    JOIN riders r ON t.rider_id = r.id 
    WHERE r.sacco_id = ?
");
$total_trips->execute([$sacco_id]);
$total_trips = $total_trips->fetchColumn();

$completed_trips = $pdo->prepare("
    SELECT COUNT(*) FROM trips t 
    JOIN riders r ON t.rider_id = r.id 
    WHERE r.sacco_id = ? AND t.status = 'completed'
");
$completed_trips->execute([$sacco_id]);
$completed_trips = $completed_trips->fetchColumn();

// Riders with expiring documents
$expiring_licenses = $pdo->prepare("
    SELECT r.*, u.full_name, u.phone 
    FROM riders r 
    JOIN users u ON r.user_id = u.id 
    WHERE r.sacco_id = ? 
    AND r.license_expiry IS NOT NULL 
    AND DATEDIFF(r.license_expiry, CURDATE()) BETWEEN 0 AND 30
");
$expiring_licenses->execute([$sacco_id]);
$expiring_licenses = $expiring_licenses->fetchAll();

$expiring_insurance = $pdo->prepare("
    SELECT r.*, u.full_name, u.phone 
    FROM riders r 
    JOIN users u ON r.user_id = u.id 
    WHERE r.sacco_id = ? 
    AND r.insurance_expiry IS NOT NULL 
    AND DATEDIFF(r.insurance_expiry, CURDATE()) BETWEEN 0 AND 30
");
$expiring_insurance->execute([$sacco_id]);
$expiring_insurance = $expiring_insurance->fetchAll();

include '../includes/header.php';
include '../includes/sidebar.php';
?>

<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h5><i class="fas fa-chart-bar"></i> SACCO Reports</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <h6>Rider Statistics</h6>
                        <table class="table table-bordered">
                            <tr>
                                <th>Total Riders</th>
                                <td><?php echo $total_riders; ?></td>
                            </tr>
                            <tr>
                                <th>Active Riders</th>
                                <td><?php echo $active_riders; ?></td>
                            </tr>
                            <tr>
                                <th>Inactive Riders</th>
                                <td><?php echo $total_riders - $active_riders; ?></td>
                            </tr>
                        </table>
                    </div>
                    <div class="col-md-6">
                        <h6>Trip Statistics</h6>
                        <table class="table table-bordered">
                            <tr>
                                <th>Total Trips</th>
                                <td><?php echo $total_trips; ?></td>
                            </tr>
                            <tr>
                                <th>Completed Trips</th>
                                <td><?php echo $completed_trips; ?></td>
                            </tr>
                            <tr>
                                <th>Completion Rate</th>
                                <td><?php echo $total_trips > 0 ? round(($completed_trips / $total_trips) * 100, 2) : 0; ?>%</td>
                            </tr>
                        </table>
                    </div>
                </div>
                
                <div class="row mt-4">
                    <div class="col-md-6">
                        <h6>Riders with Expiring Licenses (Next 30 days)</h6>
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>License #</th>
                                        <th>Expiry Date</th>
                                        <th>Phone</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($expiring_licenses as $rider): ?>
                                    <tr class="text-danger">
                                        <td><?php echo htmlspecialchars($rider['full_name']); ?></td>
                                        <td><?php echo htmlspecialchars($rider['license_number']); ?></td>
                                        <td><?php echo date('Y-m-d', strtotime($rider['license_expiry'])); ?></td>
                                        <td><?php echo htmlspecialchars($rider['phone']); ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                    <?php if (count($expiring_licenses) == 0): ?>
                                    <tr>
                                        <td colspan="4" class="text-center">No expiring licenses</td>
                                    </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <h6>Riders with Expiring Insurance (Next 30 days)</h6>
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Insurance #</th>
                                        <th>Expiry Date</th>
                                        <th>Phone</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($expiring_insurance as $rider): ?>
                                    <tr class="text-danger">
                                        <td><?php echo htmlspecialchars($rider['full_name']); ?></td>
                                        <td><?php echo htmlspecialchars($rider['insurance_number']); ?></td>
                                        <td><?php echo date('Y-m-d', strtotime($rider['insurance_expiry'])); ?></td>
                                        <td><?php echo htmlspecialchars($rider['phone']); ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                    <?php if (count($expiring_insurance) == 0): ?>
                                    <tr>
                                        <td colspan="4" class="text-center">No expiring insurance</td>
                                    </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>