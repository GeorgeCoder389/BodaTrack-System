<?php
require_once '../config/db.php';
requireRole('rider');

$message = '';
$error = '';
$profile_picture_error = '';

// Get rider details
$stmt = $pdo->prepare("
    SELECT u.*, r.*, s.name as sacco_name 
    FROM users u 
    JOIN riders r ON u.id = r.user_id 
    JOIN saccos s ON r.sacco_id = s.id 
    WHERE u.id = ?
");
$stmt->execute([$_SESSION['user_id']]);
$profile = $stmt->fetch();

if (!$profile) {
    header('Location: dashboard.php');
    exit();
}

// Handle profile picture upload
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['profile_picture'])) {
    $target_dir = "../uploads/";
    
    // Create directory if not exists
    if (!file_exists($target_dir)) {
        mkdir($target_dir, 0777, true);
    }
    
    $file = $_FILES['profile_picture'];
    $file_name = time() . '_' . preg_replace('/[^a-zA-Z0-9._-]/', '', basename($file['name']));
    $target_file = $target_dir . $file_name;
    $image_file_type = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
    
    // Valid file types
    $allowed_types = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
    
    // Check if image file is valid
    $check = getimagesize($file['tmp_name']);
    if ($check === false) {
        $profile_picture_error = "File is not an image.";
    }
    // Check file size (max 2MB)
    elseif ($file['size'] > 2 * 1024 * 1024) {
        $profile_picture_error = "File is too large. Max 2MB allowed.";
    }
    // Check file type
    elseif (!in_array($image_file_type, $allowed_types)) {
        $profile_picture_error = "Only JPG, JPEG, PNG, GIF, and WEBP files are allowed.";
    }
    else {
        // Delete old profile picture if exists
        if (!empty($profile['profile_picture']) && file_exists($target_dir . $profile['profile_picture'])) {
            unlink($target_dir . $profile['profile_picture']);
        }
        
        // Upload new file
        if (move_uploaded_file($file['tmp_name'], $target_file)) {
            // Save only filename in database
            $stmt = $pdo->prepare("UPDATE users SET profile_picture = ? WHERE id = ?");
            if ($stmt->execute([$file_name, $_SESSION['user_id']])) {
                $_SESSION['profile_picture'] = $file_name;
                $message = "Profile picture updated successfully!";
                logActivity($_SESSION['user_id'], "Updated profile picture");
                // Refresh profile data
                header("Location: profile.php");
                exit();
            } else {
                $profile_picture_error = "Failed to save profile picture.";
            }
        } else {
            $profile_picture_error = "Failed to upload image.";
        }
    }
}

// Handle remove profile picture
if (isset($_GET['remove_picture'])) {
    $target_dir = "../uploads/";
    if (!empty($profile['profile_picture']) && file_exists($target_dir . $profile['profile_picture'])) {
        unlink($target_dir . $profile['profile_picture']);
    }
    $stmt = $pdo->prepare("UPDATE users SET profile_picture = NULL WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $_SESSION['profile_picture'] = null;
    $message = "Profile picture removed successfully!";
    header("Location: profile.php");
    exit();
}

// Update profile information
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_profile'])) {
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    
    try {
        $stmt = $pdo->prepare("UPDATE users SET phone = ?, email = ? WHERE id = ?");
        $stmt->execute([$phone, $email, $_SESSION['user_id']]);
        $message = "Profile updated successfully!";
        logActivity($_SESSION['user_id'], "Updated profile information");
        
        // Refresh session data
        $_SESSION['full_name'] = $profile['full_name'];
        header("Location: profile.php");
        exit();
    } catch (PDOException $e) {
        $error = "Update failed: " . $e->getMessage();
    }
}

include '../includes/header.php';
include '../includes/sidebar.php';
?>

<style>
    .profile-image-container {
        position: relative;
        display: inline-block;
        cursor: pointer;
    }
    .profile-image {
        width: 150px;
        height: 150px;
        border-radius: 50%;
        object-fit: cover;
        border: 4px solid #667eea;
        box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        transition: all 0.3s;
    }
    .profile-image:hover {
        transform: scale(1.05);
        opacity: 0.9;
    }
    .upload-overlay {
        position: absolute;
        bottom: 10px;
        right: 10px;
        background: #667eea;
        border-radius: 50%;
        width: 40px;
        height: 40px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        border: 2px solid white;
        transition: all 0.3s;
    }
    .upload-overlay:hover {
        background: #5a67d8;
        transform: scale(1.1);
    }
    .image-preview {
        width: 150px;
        height: 150px;
        border-radius: 50%;
        object-fit: cover;
        border: 3px dashed #ddd;
    }
    .remove-picture {
        position: absolute;
        bottom: -10px;
        left: 50%;
        transform: translateX(-50%);
        background: #dc3545;
        color: white;
        border-radius: 20px;
        padding: 5px 10px;
        font-size: 12px;
        text-decoration: none;
        white-space: nowrap;
    }
    .remove-picture:hover {
        background: #c82333;
        color: white;
    }
</style>

<div class="row">
    <div class="col-md-4">
        <!-- Profile Picture Card -->
        <div class="card">
            <div class="card-header">
                <h5><i class="fas fa-camera"></i> Profile Picture</h5>
            </div>
            <div class="card-body text-center">
                <?php
                $profile_picture = !empty($profile['profile_picture']) ? '../uploads/' . $profile['profile_picture'] : 'https://ui-avatars.com/api/?background=667eea&color=fff&rounded=true&size=150&name=' . urlencode($profile['full_name']);
                ?>
                
                <div class="profile-image-container" onclick="document.getElementById('fileInput').click()">
                    <img src="<?php echo $profile_picture; ?>" alt="Profile Picture" class="profile-image" id="profileImage">
                    <div class="upload-overlay">
                        <i class="fas fa-camera"></i>
                    </div>
                </div>
                
                <form method="POST" enctype="multipart/form-data" id="uploadForm">
                    <input type="file" name="profile_picture" id="fileInput" style="display: none;" accept="image/*" onchange="previewImage(this)">
                </form>
                
                <?php if (!empty($profile['profile_picture'])): ?>
                    <div class="mt-3">
                        <a href="?remove_picture=1" class="remove-picture" onclick="return confirm('Remove your profile picture?')">
                            <i class="fas fa-trash"></i> Remove Picture
                        </a>
                    </div>
                <?php endif; ?>
                
                <div class="mt-3">
                    <small class="text-muted">
                        <i class="fas fa-info-circle"></i> Click on the image to upload<br>
                                        Allowed: JPG, PNG, GIF (Max 2MB)
                    </small>
                </div>
                
                <?php if ($profile_picture_error): ?>
                    <div class="alert alert-danger mt-3"><?php echo $profile_picture_error; ?></div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Status Card -->
        <div class="card mt-4">
            <div class="card-header">
                <h5><i class="fas fa-info-circle"></i> Account Status</h5>
            </div>
            <div class="card-body">
                <p><strong>SACCO:</strong> <?php echo htmlspecialchars($profile['sacco_name']); ?></p>
                <p>
                    <strong>Status:</strong>
                    <span class="badge bg-<?php echo $profile['status'] == 'active' ? 'success' : 'warning'; ?>">
                        <?php echo ucfirst($profile['status']); ?>
                    </span>
                </p>
                <p><strong>Member Since:</strong> <?php echo date('d M Y', strtotime($profile['created_at'])); ?></p>
            </div>
        </div>
    </div>
    
    <div class="col-md-8">
        <!-- Edit Profile Form -->
        <div class="card">
            <div class="card-header">
                <h5><i class="fas fa-edit"></i> Edit Profile Information</h5>
            </div>
            <div class="card-body">
                <?php if ($message): ?>
                    <div class="alert alert-success"><?php echo $message; ?></div>
                <?php endif; ?>
                <?php if ($error): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>
                
                <form method="POST">
                    <input type="hidden" name="update_profile" value="1">
                    
                    <div class="mb-3">
                        <label><i class="fas fa-user"></i> Full Name</label>
                        <input type="text" class="form-control" value="<?php echo htmlspecialchars($profile['full_name']); ?>" disabled>
                        <small class="text-muted">Contact your SACCO to change name</small>
                    </div>
                    
                    <div class="mb-3">
                        <label><i class="fas fa-user-tag"></i> Username</label>
                        <input type="text" class="form-control" value="<?php echo htmlspecialchars($profile['username']); ?>" disabled>
                    </div>
                    
                    <div class="mb-3">
                        <label><i class="fas fa-envelope"></i> Email</label>
                        <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($profile['email']); ?>" required>
                    </div>
                    
                    <div class="mb-3">
                        <label><i class="fas fa-phone"></i> Phone Number</label>
                        <input type="text" name="phone" class="form-control" value="<?php echo htmlspecialchars($profile['phone']); ?>">
                    </div>
                    
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Update Profile
                    </button>
                </form>
            </div>
        </div>
        
        <!-- Motorcycle Details Card -->
        <div class="card mt-4">
            <div class="card-header">
                <h5><i class="fas fa-motorcycle"></i> Motorcycle Details</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <table class="table table-sm table-borderless">
                            <tr>
                                <th>License Number:</th>
                                <td><?php echo htmlspecialchars($profile['license_number'] ?: 'Not provided'); ?></td>
                            </tr>
                            <tr>
                                <th>License Expiry:</th>
                                <td class="<?php echo $profile['license_expiry'] && strtotime($profile['license_expiry']) < strtotime('+30 days') ? 'text-danger' : ''; ?>">
                                    <?php echo $profile['license_expiry'] ? date('Y-m-d', strtotime($profile['license_expiry'])) : 'N/A'; ?>
                                </td>
                            </tr>
                            <tr>
                                <th>Insurance Number:</th>
                                <td><?php echo htmlspecialchars($profile['insurance_number'] ?: 'Not provided'); ?></td>
                            </tr>
                        </table>
                    </div>
                    <div class="col-md-6">
                        <table class="table table-sm table-borderless">
                            <tr>
                                <th>Insurance Expiry:</th>
                                <td class="<?php echo $profile['insurance_expiry'] && strtotime($profile['insurance_expiry']) < strtotime('+30 days') ? 'text-danger' : ''; ?>">
                                    <?php echo $profile['insurance_expiry'] ? date('Y-m-d', strtotime($profile['insurance_expiry'])) : 'N/A'; ?>
                                </td>
                            </tr>
                            <tr>
                                <th>Motorcycle Reg:</th>
                                <td><?php echo htmlspecialchars($profile['motorcycle_reg'] ?: 'Not provided'); ?></td>
                            </tr>
                            <tr>
                                <th>Motorcycle Model:</th>
                                <td><?php echo htmlspecialchars($profile['motorcycle_model'] ?: 'Not provided'); ?></td>
                            </tr>
                        </table>
                    </div>
                </div>
                <small class="text-muted">Contact your SACCO to update motorcycle or license details</small>
            </div>
        </div>
    </div>
</div>

<script>
function previewImage(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function(e) {
            document.getElementById('profileImage').src = e.target.result;
            document.getElementById('uploadForm').submit();
        };
        reader.readAsDataURL(input.files[0]);
    }
}
</script>

<?php include '../includes/footer.php'; ?>