<?php
require_once '../config/db.php';
requireRole('admin');

$welcome_message = '';
if (isset($_SESSION['just_logged_in'])) {
    $welcome_message = "Welcome back, " . $_SESSION['full_name'] . "! You have successfully logged in.";
    unset($_SESSION['just_logged_in']);
}

checkDocumentExpiry();

$total_saccos = $pdo->query("SELECT COUNT(*) FROM saccos")->fetchColumn();
$total_riders = $pdo->query("SELECT COUNT(*) FROM riders")->fetchColumn();
$total_trips = $pdo->query("SELECT COUNT(*) FROM trips")->fetchColumn();
$total_alerts = $pdo->query("SELECT COUNT(*) FROM alerts WHERE status = 'unread'")->fetchColumn();

$recent_alerts = $pdo->query("SELECT a.*, u.full_name as rider_name FROM alerts a LEFT JOIN riders r ON a.rider_id = r.id LEFT JOIN users u ON r.user_id = u.id ORDER BY a.created_at DESC LIMIT 5")->fetchAll();

include '../includes/header.php';
include '../includes/sidebar.php';
?>

<?php if ($welcome_message): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <i class="fas fa-smile-wink"></i> <?php echo $welcome_message; ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<div class="row">
    <div class="col-md-3"><div class="stat-card text-center"><i class="fas fa-building"></i><h3><?php echo $total_saccos; ?></h3><p>Total SACCOS</p></div></div>
    <div class="col-md-3"><div class="stat-card text-center"><i class="fas fa-users"></i><h3><?php echo $total_riders; ?></h3><p>Total Riders</p></div></div>
    <div class="col-md-3"><div class="stat-card text-center"><i class="fas fa-road"></i><h3><?php echo $total_trips; ?></h3><p>Total Trips</p></div></div>
    <div class="col-md-3"><div class="stat-card text-center"><i class="fas fa-bell"></i><h3><?php echo $total_alerts; ?></h3><p>Unread Alerts</p></div></div>
</div>

<div class="row mt-4">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header"><h5>Recent Alerts</h5></div>
            <div class="card-body">
                <table class="table table-hover">
                    <thead><tr><th>Type</th><th>Message</th><th>Rider</th><th>Date</th><th>Status</th></tr></thead>
                    <tbody>
                        <?php foreach ($recent_alerts as $alert): ?>
                        <tr>
                            <td><span class="badge bg-<?php echo $alert['type'] == 'emergency' ? 'danger' : 'warning'; ?>"><?php echo $alert['type']; ?></span></td>
                            <td><?php echo htmlspecialchars($alert['message']); ?></td>
                            <td><?php echo htmlspecialchars($alert['rider_name'] ?? 'N/A'); ?></td>
                            <td><?php echo date('Y-m-d H:i', strtotime($alert['created_at'])); ?></td>
                            <td><?php echo $alert['status']; ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>