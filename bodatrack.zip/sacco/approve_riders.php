<?php
require_once '../config/db.php';
requireRole('sacco_official');

$sacco_id = $_SESSION['sacco_id'];
$message = '';
$error = '';

// Handle approval
if (isset($_GET['approve'])) {
    $id = $_GET['approve'];
    try {
        $pdo->beginTransaction();
        
        // Update rider status
        $stmt = $pdo->prepare("UPDATE riders SET status = 'active' WHERE id = ? AND sacco_id = ? AND status = 'pending'");
        $stmt->execute([$id, $sacco_id]);
        
        if ($stmt->rowCount() > 0) {
            // Also get the user_id to update user status if needed
            $stmt2 = $pdo->prepare("SELECT user_id FROM riders WHERE id = ?");
            $stmt2->execute([$id]);
            $rider = $stmt2->fetch();
            
            if ($rider) {
                $stmt3 = $pdo->prepare("UPDATE users SET status = 'active' WHERE id = ?");
                $stmt3->execute([$rider['user_id']]);
            }
            
            $pdo->commit();
            $message = "Rider approved successfully! They can now log in and start trips.";
            logActivity($_SESSION['user_id'], "Approved rider ID: $id");
        } else {
            $pdo->rollBack();
            $error = "Rider not found or already processed";
        }
    } catch (Exception $e) {
        $pdo->rollBack();
        $error = "Error approving rider: " . $e->getMessage();
    }
}

// Handle rejection
if (isset($_GET['reject'])) {
    $id = $_GET['reject'];
    try {
        $pdo->beginTransaction();
        
        // Update rider status
        $stmt = $pdo->prepare("UPDATE riders SET status = 'inactive' WHERE id = ? AND sacco_id = ? AND status = 'pending'");
        $stmt->execute([$id, $sacco_id]);
        
        if ($stmt->rowCount() > 0) {
            // Get user_id to update user status
            $stmt2 = $pdo->prepare("SELECT user_id FROM riders WHERE id = ?");
            $stmt2->execute([$id]);
            $rider = $stmt2->fetch();
            
            if ($rider) {
                $stmt3 = $pdo->prepare("UPDATE users SET status = 'inactive' WHERE id = ?");
                $stmt3->execute([$rider['user_id']]);
            }
            
            $pdo->commit();
            $message = "Rider rejected successfully.";
            logActivity($_SESSION['user_id'], "Rejected rider ID: $id");
        } else {
            $pdo->rollBack();
            $error = "Rider not found or already processed";
        }
    } catch (Exception $e) {
        $pdo->rollBack();
        $error = "Error rejecting rider: " . $e->getMessage();
    }
}

// Get pending riders for this SACCO
$pending_riders = $pdo->prepare("
    SELECT 
        r.*, 
        u.full_name, 
        u.email, 
        u.phone, 
        u.username,
        u.created_at as registered_date
    FROM riders r 
    JOIN users u ON r.user_id = u.id 
    WHERE r.sacco_id = ? AND r.status = 'pending'
    ORDER BY r.created_at ASC
");
$pending_riders->execute([$sacco_id]);
$pending_riders = $pending_riders->fetchAll();

// Get count of pending riders
$pending_count = count($pending_riders);

include '../includes/header.php';
include '../includes/sidebar.php';
?>

<div class="card">
    <div class="card-header">
        <h5><i class="fas fa-check-circle"></i> Pending Rider Approvals</h5>
        <?php if ($pending_count > 0): ?>
            <span class="badge bg-warning float-end"><?php echo $pending_count; ?> Pending</span>
        <?php endif; ?>
    </div>
    <div class="card-body">
        <?php if ($message): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <i class="fas fa-check-circle"></i> <?php echo $message; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <?php if ($pending_count == 0): ?>
            <div class="alert alert-info text-center">
                <i class="fas fa-info-circle fa-2x"></i>
                <p class="mt-2">No pending rider registrations.</p>
                <small>When riders register, they will appear here for approval.</small>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Username</th>
                            <th>Full Name</th>
                            <th>Contact Details</th>
                            <th>License Info</th>
                            <th>Insurance Info</th>
                            <th>Motorcycle</th>
                            <th>Registered On</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $counter = 1; ?>
                        <?php foreach ($pending_riders as $rider): ?>
                        <tr class="table-warning">
                            <td><?php echo $counter++; ?></td>
                            <td>
                                <strong><?php echo htmlspecialchars($rider['username']); ?></strong>
                                <br>
                                <small class="text-muted">ID: <?php echo $rider['user_id']; ?></small>
                            </td>
                            <td>
                                <?php echo htmlspecialchars($rider['full_name']); ?>
                            </td>
                            <td>
                                <i class="fas fa-envelope"></i> <?php echo htmlspecialchars($rider['email']); ?><br>
                                <i class="fas fa-phone"></i> <?php echo htmlspecialchars($rider['phone']); ?>
                            </td>
                            <td>
                                <?php if ($rider['license_number']): ?>
                                    <i class="fas fa-id-card"></i> <?php echo htmlspecialchars($rider['license_number']); ?><br>
                                    <i class="fas fa-calendar-alt"></i> Exp: <?php echo $rider['license_expiry'] ? date('Y-m-d', strtotime($rider['license_expiry'])) : 'N/A'; ?>
                                <?php else: ?>
                                    <span class="text-muted">Not provided</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($rider['insurance_number']): ?>
                                    <i class="fas fa-file-invoice"></i> <?php echo htmlspecialchars($rider['insurance_number']); ?><br>
                                    <i class="fas fa-calendar-alt"></i> Exp: <?php echo $rider['insurance_expiry'] ? date('Y-m-d', strtotime($rider['insurance_expiry'])) : 'N/A'; ?>
                                <?php else: ?>
                                    <span class="text-muted">Not provided</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($rider['motorcycle_reg']): ?>
                                    <i class="fas fa-motorcycle"></i> <?php echo htmlspecialchars($rider['motorcycle_reg']); ?><br>
                                    <small><?php echo htmlspecialchars($rider['motorcycle_model']); ?></small>
                                <?php else: ?>
                                    <span class="text-muted">Not provided</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php echo date('d M Y, H:i', strtotime($rider['created_at'])); ?>
                             </td>
                            <td>
                                <div class="btn-group" role="group">
                                    <a href="?approve=<?php echo $rider['id']; ?>" 
                                       class="btn btn-sm btn-success" 
                                       onclick="return confirm('Approve this rider? They will be able to start working immediately.')">
                                        <i class="fas fa-check"></i> Approve
                                    </a>
                                    <a href="?reject=<?php echo $rider['id']; ?>" 
                                       class="btn btn-sm btn-danger" 
                                       onclick="return confirm('Reject this rider? This action can be reversed later.')">
                                        <i class="fas fa-times"></i> Reject
                                    </a>
                                </div>
                             </td>
                         </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <div class="mt-3">
                <small class="text-muted">
                    <i class="fas fa-info-circle"></i> Approved riders will be able to log in and start trips immediately.
                </small>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php include '../includes/footer.php'; ?>