<?php
require_once '../config/db.php';
requireRole('admin');

$message = '';
$error = '';

// Handle delete
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    try {
        $stmt = $pdo->prepare("DELETE FROM saccos WHERE id = ?");
        $stmt->execute([$id]);
        $message = "SACCO deleted successfully";
        logActivity($_SESSION['user_id'], "Deleted SACCO ID: $id");
    } catch (PDOException $e) {
        $error = "Cannot delete SACCO with associated riders";
    }
}

// Handle add/edit
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $location = $_POST['location'];
    $contact = $_POST['contact'];
    
    if (isset($_POST['edit_id']) && $_POST['edit_id']) {
        $stmt = $pdo->prepare("UPDATE saccos SET name = ?, location = ?, contact = ? WHERE id = ?");
        $stmt->execute([$name, $location, $contact, $_POST['edit_id']]);
        $message = "SACCO updated successfully";
        logActivity($_SESSION['user_id'], "Updated SACCO ID: {$_POST['edit_id']}");
    } else {
        $stmt = $pdo->prepare("INSERT INTO saccos (name, location, contact) VALUES (?, ?, ?)");
        $stmt->execute([$name, $location, $contact]);
        $message = "SACCO added successfully";
        logActivity($_SESSION['user_id'], "Added new SACCO: $name");
    }
}

$saccos = $pdo->query("SELECT * FROM saccos ORDER BY name")->fetchAll();

include '../includes/header.php';
include '../includes/sidebar.php';
?>

<div class="row">
    <div class="col-md-4">
        <div class="card">
            <div class="card-header">
                <h5>Add New SACCO</h5>
            </div>
            <div class="card-body">
                <?php if ($message): ?>
                    <div class="alert alert-success"><?php echo $message; ?></div>
                <?php endif; ?>
                <?php if ($error): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>
                
                <form method="POST">
                    <div class="mb-3">
                        <label>SACCO Name</label>
                        <input type="text" name="name" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label>Location</label>
                        <input type="text" name="location" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label>Contact</label>
                        <input type="text" name="contact" class="form-control">
                    </div>
                    <button type="submit" class="btn btn-primary">Add SACCO</button>
                </form>
            </div>
        </div>
    </div>
    
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <h5>All SACCOS</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Location</th>
                                <th>Contact</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($saccos as $sacco): ?>
                            <tr>
                                <td><?php echo $sacco['id']; ?></td>
                                <td><?php echo htmlspecialchars($sacco['name']); ?></td>
                                <td><?php echo htmlspecialchars($sacco['location']); ?></td>
                                <td><?php echo htmlspecialchars($sacco['contact']); ?></                                
                                <td>
                                    <button class="btn btn-sm btn-warning edit-btn" 
                                        data-id="<?php echo $sacco['id']; ?>"
                                        data-name="<?php echo htmlspecialchars($sacco['name']); ?>"
                                        data-location="<?php echo htmlspecialchars($sacco['location']); ?>"
                                        data-contact="<?php echo htmlspecialchars($sacco['contact']); ?>">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <a href="?delete=<?php echo $sacco['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this SACCO?')">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Edit Modal -->
<div class="modal fade" id="editModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Edit SACCO</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <input type="hidden" name="edit_id" id="edit_id">
                    <div class="mb-3">
                        <label>SACCO Name</label>
                        <input type="text" name="name" id="edit_name" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label>Location</label>
                        <input type="text" name="location" id="edit_location" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label>Contact</label>
                        <input type="text" name="contact" id="edit_contact" class="form-control">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save Changes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.querySelectorAll('.edit-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        document.getElementById('edit_id').value = this.dataset.id;
        document.getElementById('edit_name').value = this.dataset.name;
        document.getElementById('edit_location').value = this.dataset.location;
        document.getElementById('edit_contact').value = this.dataset.contact;
        new bootstrap.Modal(document.getElementById('editModal')).show();
    });
});
</script>

<?php include '../includes/footer.php'; ?>