<?php
require_once '../config/db.php';
requireRole('admin');

$riders = $pdo->query("
    SELECT r.*, u.full_name, u.email, u.phone, s.name as sacco_name 
    FROM riders r 
    JOIN users u ON r.user_id = u.id 
    JOIN saccos s ON r.sacco_id = s.id 
    ORDER BY r.created_at DESC
")->fetchAll();

include '../includes/header.php';
include '../includes/sidebar.php';
?>

<div class="card">
    <div class="card-header">
        <h5><i class="fas fa-id-card"></i> All Registered Riders</h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover" id="ridersTable">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email/Phone</th>
                        <th>SACCO</th>
                        <th>License #</th>
                        <th>License Expiry</th>
                        <th>Insurance Expiry</th>
                        <th>Motorcycle Reg</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($riders as $rider): ?>
                    <tr>
                        <td><?php echo $rider['id']; ?></td>
                        <td><?php echo htmlspecialchars($rider['full_name']); ?></td>
                        <td>
                            <?php echo htmlspecialchars($rider['email']); ?><br>
                            <small><?php echo htmlspecialchars($rider['phone']); ?></small>
                        </td>
                        <td><?php echo htmlspecialchars($rider['sacco_name']); ?></td>
                        <td><?php echo htmlspecialchars($rider['license_number']); ?></td>
                        <td class="<?php echo $rider['license_expiry'] && strtotime($rider['license_expiry']) < strtotime('+30 days') ? 'text-danger' : ''; ?>">
                            <?php echo $rider['license_expiry'] ? date('Y-m-d', strtotime($rider['license_expiry'])) : 'N/A'; ?>
                        </td>
                        <td class="<?php echo $rider['insurance_expiry'] && strtotime($rider['insurance_expiry']) < strtotime('+30 days') ? 'text-danger' : ''; ?>">
                            <?php echo $rider['insurance_expiry'] ? date('Y-m-d', strtotime($rider['insurance_expiry'])) : 'N/A'; ?>
                        </td>
                        <td><?php echo htmlspecialchars($rider['motorcycle_reg']); ?></td>
                        <td>
                            <span class="badge bg-<?php 
                                echo $rider['status'] == 'active' ? 'success' : 
                                    ($rider['status'] == 'pending' ? 'warning' : 'danger'); 
                            ?>">
                                <?php echo $rider['status']; ?>
                            </span>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>