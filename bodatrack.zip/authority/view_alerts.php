<?php
require_once '../config/db.php';
requireRole('authority');

// Mark alert as resolved
if (isset($_GET['resolve'])) {
    $stmt = $pdo->prepare("UPDATE alerts SET status = 'resolved' WHERE id = ? AND type = 'emergency'");
    $stmt->execute([$_GET['resolve']]);
    header('Location: view_alerts.php');
    exit();
}

$alerts = $pdo->query("
    SELECT a.*, u.full_name as rider_name, s.name as sacco_name 
    FROM alerts a 
    LEFT JOIN riders r ON a.rider_id = r.id 
    LEFT JOIN users u ON r.user_id = u.id 
    LEFT JOIN saccos s ON r.sacco_id = s.id 
    WHERE a.type = 'emergency'
    ORDER BY a.created_at DESC 
    LIMIT 50
")->fetchAll();

include '../includes/header.php';
include '../includes/sidebar.php';
?>

<div class="card">
    <div class="card-header bg-danger text-white">
        <h5><i class="fas fa-bell"></i> Emergency Alerts</h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Severity</th>
                        <th>Rider</th>
                        <th>SACCO</th>
                        <th>Message</th>
                        <th>Time</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($alerts as $alert): ?>
                    <tr class="<?php echo $alert['status'] == 'unread' ? 'table-danger' : ''; ?>">
                        <td>
                            <span class="badge bg-<?php 
                                echo $alert['severity'] == 'critical' ? 'danger' : 'warning'; 
                            ?>">
                                <?php echo $alert['severity']; ?>
                            </span>
                        </td>
                        <td><?php echo htmlspecialchars($alert['rider_name'] ?? 'Unknown'); ?></td>
                        <td><?php echo htmlspecialchars($alert['sacco_name'] ?? 'N/A'); ?></td>
                        <td><?php echo htmlspecialchars($alert['message']); ?></td>
                        <td><?php echo date('Y-m-d H:i:s', strtotime($alert['created_at'])); ?></td>
                        <td><?php echo $alert['status']; ?></td>
                        <td>
                            <?php if ($alert['status'] != 'resolved'): ?>
                                <a href="?resolve=<?php echo $alert['id']; ?>" class="btn btn-sm btn-success" onclick="return confirm('Mark this emergency as resolved?')">
                                    <i class="fas fa-check"></i> Resolve
                                </a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>