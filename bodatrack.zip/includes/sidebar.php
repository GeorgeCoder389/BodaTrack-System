<?php
$current_page = basename($_SERVER['PHP_SELF']);
$role = $_SESSION['role'] ?? '';
?>
<nav class="navbar navbar-dark bg-dark fixed-top">
    <div class="container-fluid">
        <a class="navbar-brand" href="../index.php"><i class="fas fa-motorcycle"></i> BodaTrack</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasNavbar">
            <div class="offcanvas-header bg-dark text-white">
                <h5 class="offcanvas-title">Menu</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas"></button>
            </div>
            <div class="offcanvas-body bg-dark">
                <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
                    <li class="nav-item"><a class="nav-link" href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                    
                    <?php if ($role == 'admin'): ?>
                        <li class="nav-item"><a class="nav-link" href="manage_saccos.php"><i class="fas fa-building"></i> Manage SACCOS</a></li>
                        <li class="nav-item"><a class="nav-link" href="manage_users.php"><i class="fas fa-users"></i> Manage Users</a></li>
                        <li class="nav-item"><a class="nav-link" href="view_riders.php"><i class="fas fa-id-card"></i> All Riders</a></li>
                        <li class="nav-item"><a class="nav-link" href="view_trips.php"><i class="fas fa-road"></i> All Trips</a></li>
                        <li class="nav-item"><a class="nav-link" href="view_alerts.php"><i class="fas fa-bell"></i> Alerts</a></li>
                        <li class="nav-item"><a class="nav-link" href="reports.php"><i class="fas fa-chart-bar"></i> Reports</a></li>
                    <?php elseif ($role == 'sacco_official'): ?>
                        <li class="nav-item"><a class="nav-link" href="manage_riders.php"><i class="fas fa-id-card"></i> Manage Riders</a></li>
                        <li class="nav-item"><a class="nav-link" href="approve_riders.php"><i class="fas fa-check-circle"></i> Approve Riders</a></li>
                        <li class="nav-item"><a class="nav-link" href="view_trips.php"><i class="fas fa-road"></i> View Trips</a></li>
                        <li class="nav-item"><a class="nav-link" href="view_alerts.php"><i class="fas fa-bell"></i> Alerts</a></li>
                        <li class="nav-item"><a class="nav-link" href="reports.php"><i class="fas fa-chart-bar"></i> Reports</a></li>
                    <?php elseif ($role == 'rider'): ?>
                        <li class="nav-item"><a class="nav-link" href="profile.php"><i class="fas fa-user"></i> My Profile</a></li>
                        <li class="nav-item"><a class="nav-link" href="update_location.php"><i class="fas fa-map-marker-alt"></i> Update Location</a></li>
                        <li class="nav-item"><a class="nav-link" href="manage_trips.php"><i class="fas fa-play-circle"></i> Start/End Trip</a></li>
                        <li class="nav-item"><a class="nav-link" href="trip_history.php"><i class="fas fa-history"></i> Trip History</a></li>
                        <li class="nav-item"><a class="nav-link" href="emergency.php"><i class="fas fa-exclamation-triangle text-danger"></i> Emergency Alert</a></li>
                        <li class="nav-item"><a class="nav-link" href="view_alerts.php"><i class="fas fa-bell"></i> My Alerts</a></li>
                    <?php elseif ($role == 'authority'): ?>
                        <li class="nav-item"><a class="nav-link" href="view_riders.php"><i class="fas fa-id-card"></i> View Riders</a></li>
                        <li class="nav-item"><a class="nav-link" href="view_trips.php"><i class="fas fa-road"></i> View Trips</a></li>
                        <li class="nav-item"><a class="nav-link" href="view_alerts.php"><i class="fas fa-bell"></i> Alerts</a></li>
                        <li class="nav-item"><a class="nav-link" href="reports.php"><i class="fas fa-chart-bar"></i> Reports</a></li>
                    <?php endif; ?>
                    
                    <li class="nav-item mt-3">
                        <hr class="bg-secondary">
                        <a class="nav-link text-danger" href="../logout.php">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</nav>
<div class="container-fluid" style="margin-top: 70px;"></div>