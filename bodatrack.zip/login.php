<?php
require_once 'config/db.php';

// Check for logout message
$logout_message = '';
$logout_message_type = '';

if (isset($_SESSION['logout_message'])) {
    $logout_message = $_SESSION['logout_message'];
    $logout_message_type = $_SESSION['logout_message_type'] ?? 'success';
    unset($_SESSION['logout_message']);
    unset($_SESSION['logout_message_type']);
}

if (isLoggedIn()) {
    header('Location: index.php');
    exit();
}

$error = '';
$success_message = '';
$redirect_url = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? AND status = 'active'");
    $stmt->execute([$username]);
    $user = $stmt->fetch();
    
    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role'] = $user['role'];
        $_SESSION['full_name'] = $user['full_name'];
        $_SESSION['sacco_id'] = $user['sacco_id'];
        $_SESSION['just_logged_in'] = true;
        
        logActivity($user['id'], 'User logged in');
        
        $success_message = "Welcome back, " . $user['full_name'] . "! Redirecting to your dashboard...";
        
        switch($user['role']) {
            case 'admin': $redirect_url = 'admin/dashboard.php'; break;
            case 'sacco_official': $redirect_url = 'sacco/dashboard.php'; break;
            case 'rider': $redirect_url = 'rider/dashboard.php'; break;
            case 'authority': $redirect_url = 'authority/dashboard.php'; break;
            default: $redirect_url = 'dashboard.php';
        }
    } else {
        $error = 'Invalid username or password. Please try again.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - BodaTrack</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        .login-container { width: 100%; max-width: 450px; margin: 0 auto; padding: 20px; }
        .login-card { background: white; border-radius: 20px; padding: 40px; box-shadow: 0 20px 60px rgba(0,0,0,0.3); animation: fadeInUp 0.6s ease; }
        @keyframes fadeInUp { from { opacity: 0; transform: translateY(30px); } to { opacity: 1; transform: translateY(0); } }
        .logo-icon { font-size: 60px; color: #667eea; text-align: center; margin-bottom: 20px; }
        .logo h2 { text-align: center; font-size: 28px; color: #333; }
        .logo p { text-align: center; color: #666; font-size: 14px; margin-bottom: 30px; }
        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; margin-bottom: 8px; color: #333; font-weight: 500; }
        .input-group { position: relative; }
        .input-group i { position: absolute; left: 15px; top: 50%; transform: translateY(-50%); color: #999; }
        .form-control { width: 100%; padding: 12px 15px 12px 45px; border: 2px solid #e0e0e0; border-radius: 10px; transition: all 0.3s; }
        .form-control:focus { outline: none; border-color: #667eea; box-shadow: 0 0 0 3px rgba(102,126,234,0.1); }
        .btn-login { width: 100%; padding: 12px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; border: none; border-radius: 10px; font-size: 16px; font-weight: bold; cursor: pointer; transition: all 0.3s; }
        .btn-login:hover { transform: translateY(-2px); box-shadow: 0 5px 20px rgba(102,126,234,0.4); }
        .alert { padding: 12px 15px; border-radius: 10px; margin-bottom: 20px; animation: slideIn 0.3s ease; }
        @keyframes slideIn { from { opacity: 0; transform: translateX(-20px); } to { opacity: 1; transform: translateX(0); } }
        .alert-danger { background-color: #fee; color: #c33; border-left: 4px solid #c33; }
        .alert-success { background-color: #e8f5e9; color: #2e7d32; border-left: 4px solid #2e7d32; text-align: center; }
        .register-link { text-align: center; margin-top: 25px; padding-top: 20px; border-top: 1px solid #eee; }
        .register-link a { color: #667eea; text-decoration: none; font-weight: 500; }
        .footer { text-align: center; margin-top: 20px; font-size: 12px; color: #999; }
        .success-overlay { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.8); display: flex; justify-content: center; align-items: center; z-index: 9999; }
        .success-card { background: white; border-radius: 20px; padding: 40px; text-align: center; max-width: 400px; margin: 20px; animation: scaleIn 0.4s ease; }
        @keyframes scaleIn { from { opacity: 0; transform: scale(0.8); } to { opacity: 1; transform: scale(1); } }
        .success-icon { font-size: 80px; color: #4caf50; margin-bottom: 20px; animation: checkmark 0.5s ease-in-out; }
        @keyframes checkmark { 0% { transform: scale(0); opacity: 0; } 50% { transform: scale(1.2); } 100% { transform: scale(1); opacity: 1; } }
        .spinner { width: 40px; height: 40px; border: 4px solid #f3f3f3; border-top: 4px solid #667eea; border-radius: 50%; animation: spin 1s linear infinite; margin: 20px auto; }
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
    </style>
</head>
<body>
    <div class="d-flex justify-content-center align-items-center min-vh-100">
        <div class="login-container">
            <div class="login-card">
                <div class="logo">
                    <div class="logo-icon">🏍️</div>
                    <h2>BodaTrack</h2>
                    <p>Motorcycle Rider Management System</p>
                </div>
                
                <?php if ($logout_message): ?>
                    <div class="alert alert-<?php echo $logout_message_type == 'success' ? 'success' : 'info'; ?>">
                        <i class="fas <?php echo $logout_message_type == 'success' ? 'fa-check-circle' : 'fa-info-circle'; ?>"></i>
                        <?php echo htmlspecialchars($logout_message); ?>
                    </div>
                <?php endif; ?>
                
                <?php if ($error): ?>
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                    </div>
                <?php endif; ?>
                
                <form method="POST" id="loginForm">
                    <div class="form-group">
                        <label>Username</label>
                        <div class="input-group">
                            <i class="fas fa-user"></i>
                            <input type="text" name="username" class="form-control" placeholder="Enter your username" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Password</label>
                        <div class="input-group">
                            <i class="fas fa-lock"></i>
                            <input type="password" name="password" class="form-control" placeholder="Enter your password" required>
                        </div>
                    </div>
                    <button type="submit" class="btn-login" id="loginBtn">
                        <i class="fas fa-sign-in-alt"></i> Login
                    </button>
                </form>
                
                <div class="register-link">
                    <a href="register.php"><i class="fas fa-user-plus"></i> New rider? Register here</a>
                </div>
                
                <div class="footer">
                    <i class="fas fa-shield-alt"></i> Secure Login | &copy; <?php echo date('Y'); ?> BodaTrack
                </div>
            </div>
        </div>
    </div>
    
    <?php if ($success_message): ?>
    <div class="success-overlay" id="successOverlay">
        <div class="success-card">
            <div class="success-icon"><i class="fas fa-check-circle"></i></div>
            <h3 style="color: #2e7d32;">Login Successful!</h3>
            <p><?php echo $success_message; ?></p>
            <div class="spinner"></div>
            <p class="redirect-text">Please wait...</p>
        </div>
    </div>
    <script>setTimeout(function() { window.location.href = '<?php echo $redirect_url; ?>'; }, 2000);</script>
    <?php endif; ?>
    
    <script>
        document.getElementById('loginForm')?.addEventListener('submit', function() {
            const btn = document.getElementById('loginBtn');
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Logging in...';
            btn.disabled = true;
        });
    </script>
</body>
</html>