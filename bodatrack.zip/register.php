<?php
require_once 'config/db.php';

$error = '';
$success = '';

// Get all SACCOS for dropdown
$stmt = $pdo->query("SELECT id, name, location FROM saccos ORDER BY name");
$saccos = $stmt->fetchAll();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $full_name = trim($_POST['full_name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $sacco_id = $_POST['sacco_id'];
    $license_number = trim($_POST['license_number']);
    $license_expiry = $_POST['license_expiry'];
    $insurance_number = trim($_POST['insurance_number']);
    $insurance_expiry = $_POST['insurance_expiry'];
    $motorcycle_reg = trim($_POST['motorcycle_reg']);
    $motorcycle_model = trim($_POST['motorcycle_model']);
    
    try {
        $pdo->beginTransaction();
        
        // Check if username or email exists
        $check = $pdo->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
        $check->execute([$username, $email]);
        if ($check->fetch()) {
            throw new Exception("Username or email already exists");
        }
        
        // Create user account
        $stmt = $pdo->prepare("INSERT INTO users (username, password, full_name, email, phone, role, status) VALUES (?, ?, ?, ?, ?, 'rider', 'active')");
        $stmt->execute([$username, $password, $full_name, $email, $phone]);
        $user_id = $pdo->lastInsertId();
        
        // Create rider profile (pending approval)
        $stmt = $pdo->prepare("INSERT INTO riders (user_id, sacco_id, license_number, license_expiry, insurance_number, insurance_expiry, motorcycle_reg, motorcycle_model, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending')");
        $stmt->execute([$user_id, $sacco_id, $license_number, $license_expiry, $insurance_number, $insurance_expiry, $motorcycle_reg, $motorcycle_model]);
        
        $pdo->commit();
        $success = "Registration successful! Please wait for SACCO approval.";
    } catch (Exception $e) {
        $pdo->rollBack();
        $error = "Registration failed: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register as Rider - BodaTrack</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        .register-container {
            max-width: 900px;
            margin: 0 auto;
        }
        .register-card {
            background: white;
            border-radius: 20px;
            padding: 30px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            animation: fadeInUp 0.6s ease;
        }
        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .form-header {
            text-align: center;
            margin-bottom: 30px;
        }
        .form-header i {
            font-size: 60px;
            color: #667eea;
        }
        .form-header h2 {
            margin-top: 10px;
            color: #333;
        }
        .form-header p {
            color: #666;
        }
        .section-title {
            background: #f5f5f5;
            padding: 10px 15px;
            border-radius: 10px;
            margin: 20px 0 15px 0;
            font-weight: bold;
            color: #667eea;
        }
        .btn-register {
            width: 100%;
            padding: 12px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s;
            margin-top: 20px;
        }
        .btn-register:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(102,126,234,0.4);
        }
        .login-link {
            text-align: center;
            margin-top: 20px;
        }
        .login-link a {
            color: #667eea;
            text-decoration: none;
        }
    </style>
</head>
<body>
    <div class="register-container">
        <div class="register-card">
            <div class="form-header">
                <i class="fas fa-motorcycle"></i>
                <h2>Rider Registration</h2>
                <p>Join BodaTrack - Safe, Secure, Smart</p>
            </div>
            
            <?php if ($error): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?php echo $success; ?>
                    <br><br>
                    <a href="login.php" class="btn btn-primary">Go to Login</a>
                </div>
            <?php else: ?>
                <form method="POST">
                    <div class="section-title">
                        <i class="fas fa-user"></i> Personal Information
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label>Username *</label>
                            <input type="text" name="username" class="form-control" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>Password *</label>
                            <input type="password" name="password" class="form-control" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>Full Name *</label>
                            <input type="text" name="full_name" class="form-control" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>Email *</label>
                            <input type="email" name="email" class="form-control" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>Phone Number *</label>
                            <input type="text" name="phone" class="form-control" placeholder="0712345678" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>Select SACCO *</label>
                            <select name="sacco_id" class="form-control" required>
                                <option value="">-- Select your SACCO --</option>
                                <?php foreach ($saccos as $sacco): ?>
                                    <option value="<?php echo $sacco['id']; ?>">
                                        <?php echo htmlspecialchars($sacco['name']); ?> 
                                        (<?php echo htmlspecialchars($sacco['location']); ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <small class="text-muted">Join a SACCO near you</small>
                        </div>
                    </div>
                    
                    <div class="section-title">
                        <i class="fas fa-id-card"></i> License & Insurance Details
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label>Driving License Number</label>
                            <input type="text" name="license_number" class="form-control" placeholder="e.g., B123456">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>License Expiry Date</label>
                            <input type="date" name="license_expiry" class="form-control">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>Insurance Policy Number</label>
                            <input type="text" name="insurance_number" class="form-control" placeholder="e.g., INS123456">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>Insurance Expiry Date</label>
                            <input type="date" name="insurance_expiry" class="form-control">
                        </div>
                    </div>
                    
                    <div class="section-title">
                        <i class="fas fa-motorcycle"></i> Motorcycle Details
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label>Motorcycle Registration Number</label>
                            <input type="text" name="motorcycle_reg" class="form-control" placeholder="e.g., Kxxx xxx">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>Motorcycle Model</label>
                            <input type="text" name="motorcycle_model" class="form-control" placeholder="e.g., Bajaj Boxer, TVS">
                        </div>
                    </div>
                    
                    <button type="submit" class="btn-register">
                        <i class="fas fa-user-plus"></i> Register Now
                    </button>
                </form>
                
                <div class="login-link">
                    Already have an account? <a href="login.php">Login here</a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>