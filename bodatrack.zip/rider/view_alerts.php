<?php
require_once '../config/db.php';
requireRole('rider');

// Get rider ID
$stmt = $pdo->prepare("SELECT id FROM riders WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$rider = $stmt->fetch();
$rider_id = $rider['id'];

// Mark alert as read
if (isset($_GET['read'])) {
    $stmt = $pdo->prepare("UPDATE alerts SET status = 'read' WHERE id = ? AND rider_id = ?");
    $stmt->execute([$_GET['read'], $rider_id]);
    header('Location: view_alerts.php');
    exit();
}

$alerts = $pdo->prepare("
    SELECT * FROM alerts 
    WHERE rider_id = ? 
    ORDER BY created_at DESC 
    LIMIT 50
");
$alerts->execute([$rider_id]);
$alerts = $alerts->fetchAll();

include '../includes/header.php';
include '../includes/sidebar.php';
?>

<div class="card">
    <div class="card-header">
        <h5><i class="fas fa-bell"></i> My Alerts</h5>
    </div>
    <div class="card-body">
        <?php if (count($alerts) == 0): ?>
            <div class="alert alert-info">No alerts found.</div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Type</th>
                            <th>Severity</th>
                            <th>Message</th>
                            <th>Date</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($alerts as $alert): ?>
                        <tr class="<?php echo $alert['status'] == 'unread' ? 'table-warning' : ''; ?>">
                            <td>
                                <span class="badge bg-<?php 
                                    echo $alert['type'] == 'emergency' ? 'danger' : 
                                        ($alert['type'] == 'document_expiry' ? 'warning' : 'info'); 
                                ?>">
                                    <?php echo $alert['type']; ?>
                                </span>
                            </td>
                            <td>
                                <span class="badge bg-<?php 
                                    echo $alert['severity'] == 'critical' ? 'danger' : 
                                        ($alert['severity'] == 'high' ? 'warning' : 'secondary'); 
                                ?>">
                                    <?php echo $alert['severity']; ?>
                                </span>
                            </td>
                            <td><?php echo htmlspecialchars($alert['message']); ?></td>
                            <td><?php echo date('Y-m-d H:i', strtotime($alert['created_at'])); ?></td>
                            <td><?php echo $alert['status']; ?></td>
                            <td>
                                <?php if ($alert['status'] == 'unread'): ?>
                                    <a href="?read=<?php echo $alert['id']; ?>" class="btn btn-sm btn-info">Mark Read</a>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php include '../includes/footer.php'; ?>