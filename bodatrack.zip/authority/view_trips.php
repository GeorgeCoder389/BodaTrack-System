<?php
require_once '../config/db.php';
requireRole('authority');

$trips = $pdo->query("
    SELECT t.*, u.full_name as rider_name, s.name as sacco_name 
    FROM trips t 
    JOIN riders r ON t.rider_id = r.id 
    JOIN users u ON r.user_id = u.id 
    JOIN saccos s ON r.sacco_id = s.id 
    WHERE t.status = 'completed'
    ORDER BY t.created_at DESC 
    LIMIT 100
")->fetchAll();

include '../includes/header.php';
include '../includes/sidebar.php';
?>

<div class="card">
    <div class="card-header">
        <h5><i class="fas fa-road"></i> Trip Records</h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Rider</th>
                        <th>SACCO</th>
                        <th>Start Location</th>
                        <th>End Location</th>
                        <th>Distance</th>
                        <th>Fare</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($trips as $trip): ?>
                    <tr>
                        <td><?php echo date('Y-m-d H:i', strtotime($trip['created_at'])); ?></td>
                        <td><?php echo htmlspecialchars($trip['rider_name']); ?></td>
                        <td><?php echo htmlspecialchars($trip['sacco_name']); ?></td>
                        <td><?php echo htmlspecialchars($trip['start_location']); ?></td>
                        <td><?php echo htmlspecialchars($trip['end_location']); ?></td>
                        <td><?php echo $trip['distance_km'] ?? '-'; ?> km</td>
                        <td><?php echo $trip['fare'] ? 'KES ' . number_format($trip['fare']) : '-'; ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>