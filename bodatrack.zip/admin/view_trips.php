<?php
require_once '../config/db.php';
requireRole('admin');

$trips = $pdo->query("
    SELECT t.*, u.full_name as rider_name, u.phone 
    FROM trips t 
    JOIN riders r ON t.rider_id = r.id 
    JOIN users u ON r.user_id = u.id 
    ORDER BY t.created_at DESC 
    LIMIT 100
")->fetchAll();

include '../includes/header.php';
include '../includes/sidebar.php';
?>

<div class="card">
    <div class="card-header">
        <h5><i class="fas fa-road"></i> All Trips</h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Rider</th>
                        <th>Start Location</th>
                        <th>End Location</th>
                        <th>Start Time</th>
                        <th>End Time</th>
                        <th>Distance (km)</th>
                        <th>Fare (KES)</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($trips as $trip): ?>
                    <tr>
                        <td><?php echo $trip['id']; ?></td>
                        <td><?php echo htmlspecialchars($trip['rider_name']); ?></td>
                        <td><?php echo htmlspecialchars($trip['start_location']); ?></td>
                        <td><?php echo htmlspecialchars($trip['end_location']); ?></td>
                        <td><?php echo date('Y-m-d H:i', strtotime($trip['start_time'])); ?></td>
                        <td><?php echo $trip['end_time'] ? date('Y-m-d H:i', strtotime($trip['end_time'])) : '-'; ?></td>
                        <td><?php echo $trip['distance_km'] ?? '-'; ?></td>
                        <td><?php echo $trip['fare'] ? 'KES ' . number_format($trip['fare']) : '-'; ?></td>
                        <td>
                            <span class="badge bg-<?php 
                                echo $trip['status'] == 'completed' ? 'success' : 
                                    ($trip['status'] == 'ongoing' ? 'primary' : 'danger'); 
                            ?>">
                                <?php echo $trip['status']; ?>
                            </span>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>