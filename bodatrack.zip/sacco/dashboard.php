<?php
require_once '../config/db.php';
requireRole('sacco_official');

$sacco_id = $_SESSION['sacco_id'];

// Get statistics for this SACCO
$total_riders = $pdo->prepare("SELECT COUNT(*) FROM riders WHERE sacco_id = ?");
$total_riders->execute([$sacco_id]);
$total_riders = $total_riders->fetchColumn();

$active_riders = $pdo->prepare("SELECT COUNT(*) FROM riders WHERE sacco_id = ? AND status = 'active'");
$active_riders->execute([$sacco_id]);
$active_riders = $active_riders->fetchColumn();

$pending_riders = $pdo->prepare("SELECT COUNT(*) FROM riders WHERE sacco_id = ? AND status = 'pending'");
$pending_riders->execute([$sacco_id]);
$pending_riders = $pending_riders->fetchColumn();

$total_trips = $pdo->prepare("
    SELECT COUNT(*) FROM trips t 
    JOIN riders r ON t.rider_id = r.id 
    WHERE r.sacco_id = ?
");
$total_trips->execute([$sacco_id]);
$total_trips = $total_trips->fetchColumn();

$recent_alerts = $pdo->prepare("
    SELECT a.*, u.full_name as rider_name 
    FROM alerts a 
    LEFT JOIN riders r ON a.rider_id = r.id 
    LEFT JOIN users u ON r.user_id = u.id 
    WHERE a.sacco_id = ? OR a.rider_id IS NULL
    ORDER BY a.created_at DESC 
    LIMIT 5
");
$recent_alerts->execute([$sacco_id]);
$recent_alerts = $recent_alerts->fetchAll();

include '../includes/header.php';
include '../includes/sidebar.php';
?>

<div class="row">
    <div class="col-md-3">
        <div class="stat-card text-center">
            <i class="fas fa-users"></i>
            <h3><?php echo $total_riders; ?></h3>
            <p>Total Riders</p>
        </div>
    </div>
    <div class="col-md-3">
        <div class="stat-card text-center">
            <i class="fas fa-check-circle"></i>
            <h3><?php echo $active_riders; ?></h3>
            <p>Active Riders</p>
        </div>
    </div>
    <div class="col-md-3">
        <div class="stat-card text-center">
            <i class="fas fa-clock"></i>
            <h3><?php echo $pending_riders; ?></h3>
            <p>Pending Approval</p>
        </div>
    </div>
    <div class="col-md-3">
        <div class="stat-card text-center">
            <i class="fas fa-road"></i>
            <h3><?php echo $total_trips; ?></h3>
            <p>Total Trips</p>
        </div>
    </div>
</div>

<div class="row mt-4">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h5>Recent Alerts</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Type</th>
                                <th>Message</th>
                                <th>Rider</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($recent_alerts as $alert): ?>
                            <tr>
                                <td>
                                    <span class="badge bg-<?php echo $alert['type'] == 'emergency' ? 'danger' : 'warning'; ?>">
                                        <?php echo $alert['type']; ?>
                                    </span>
                                </td>
                                <td><?php echo htmlspecialchars($alert['message']); ?></td>
                                <td><?php echo htmlspecialchars($alert['rider_name'] ?? 'System'); ?></td>
                                <td><?php echo date('Y-m-d H:i', strtotime($alert['created_at'])); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>