<?php
require_once '../config/db.php';
requireRole('rider');

// Get rider ID
$stmt = $pdo->prepare("SELECT id FROM riders WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$rider = $stmt->fetch();
$rider_id = $rider['id'];

// Get all trips for this rider
$trips = $pdo->prepare("
    SELECT * FROM trips 
    WHERE rider_id = ? 
    ORDER BY created_at DESC 
    LIMIT 50
");
$trips->execute([$rider_id]);
$trips = $trips->fetchAll();

// Calculate statistics
$total_distance = array_sum(array_column($trips, 'distance_km'));
$total_fare = array_sum(array_column($trips, 'fare'));
$completed_count = count(array_filter($trips, function($t) { return $t['status'] == 'completed'; }));

include '../includes/header.php';
include '../includes/sidebar.php';
?>

<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h5><i class="fas fa-history"></i> Trip History</h5>
            </div>
            <div class="card-body">
                <div class="row mb-4">
                    <div class="col-md-4">
                        <div class="stat-card text-center">
                            <i class="fas fa-road"></i>
                            <h3><?php echo count($trips); ?></h3>
                            <p>Total Trips</p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="stat-card text-center">
                            <i class="fas fa-chart-line"></i>
                            <h3><?php echo round($total_distance, 1); ?> km</h3>
                            <p>Total Distance</p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="stat-card text-center">
                            <i class="fas fa-money-bill"></i>
                            <h3>KES <?php echo number_format($total_fare); ?></h3>
                            <p>Total Earnings</p>
                        </div>
                    </div>
                </div>
                
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Start Location</th>
                                <th>End Location</th>
                                <th>Start Time</th>
                                <th>End Time</th>
                                <th>Distance</th>
                                <th>Fare</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($trips as $trip): ?>
                            <tr>
                                <td><?php echo date('Y-m-d', strtotime($trip['created_at'])); ?></td>
                                <td><?php echo htmlspecialchars($trip['start_location']); ?></td                                
                                <td><?php echo htmlspecialchars($trip['end_location'] ?: '-'); ?></td>
                                <td><?php echo date('H:i', strtotime($trip['start_time'])); ?></td>
                                <td><?php echo $trip['end_time'] ? date('H:i', strtotime($trip['end_time'])) : '-'; ?></td>
                                <td><?php echo $trip['distance_km'] ?? '-'; ?> km</td>
                                <td><?php echo $trip['fare'] ? 'KES ' . number_format($trip['fare']) : '-'; ?></td>
                                <td>
                                    <span class="badge bg-<?php 
                                        echo $trip['status'] == 'completed' ? 'success' : 
                                            ($trip['status'] == 'ongoing' ? 'primary' : 'danger'); 
                                    ?>">
                                        <?php echo $trip['status']; ?>
                                    </span>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            <?php if (count($trips) == 0): ?>
                            <tr>
                                <td colspan="8" class="text-center">No trips found. Start your first trip!</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>